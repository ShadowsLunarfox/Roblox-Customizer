//https://dom.rojo.space/binary.html

//API DUMP
//https://s3.amazonaws.com/setup.roblox.com/versionQTStudio
//https://s3.amazonaws.com/setup.roblox.com/[VERSION_HERE]-API-Dump.json

import * as THREE from 'three';
import RBXSimpleView from './rbx-simple-view';
import { download, hexToRgb, lerp, mapNum, rad, RNG, rotationMatrixToEulerAngles } from '../misc/misc';
import { intToRgb, readReferents, untransformInt32, untransformInt64 } from './rbx-read-helper';
import type { Mat4x4, Vec3 } from '../mesh/mesh';
import { BodyPartNameToEnum, DataType, magic, StringBufferProperties, xmlMagic } from './constant';
import * as LZ4 from './lz4'
import * as fzstd from 'fzstd';
import { GetWrapperForInstance, InstanceWrapper } from './instance/InstanceWrapper';
import { BrickColors } from '../avatar/constant';
import { FLAGS } from '../misc/flags';
import { error, log, warn } from '../misc/logger';

//datatype structs
/**
 * @category DataModelProperty
 */
export class UDim {
    Scale: number = 0 //Float32
    Offset: number = 0 //Int32

    constructor(Scale: number = 0, Offset: number = 0) {
        this.Scale = Scale
        this.Offset = Offset
    }

    clone() {
        const copy = new UDim()
        copy.Scale = this.Scale
        copy.Offset = this.Offset
        return copy
    }
}

/**
 * @category DataModelProperty
 */
export class UDim2 {
    X: UDim = new UDim()
    Y: UDim = new UDim()

    clone() {
        const copy = new UDim2()
        copy.X = this.X.clone()
        copy.Y = this.Y.clone()
        return copy
    }
}

/**
 * @category DataModelProperty
 */
export class Ray {
    Origin: Vec3 = [0,0,0]
    Direction: Vec3 = [0,0,0]

    clone() {
        const copy = new Ray()
        copy.Origin[0] = this.Origin[0]
        copy.Origin[1] = this.Origin[1]
        copy.Origin[2] = this.Origin[2]

        copy.Direction[0] = this.Direction[0]
        copy.Direction[1] = this.Direction[1]
        copy.Direction[2] = this.Direction[2]
        return copy
    }
}

/**
 * @category DataModelProperty
 */
export class Vector2 {
    X: number = 0
    Y: number = 0

    constructor(X: number = 0, Y: number = 0) {
        this.X = X
        this.Y = Y
    }

    clone() {
        return new Vector2(this.X, this.Y)
    }

    isSame(other: Vector2) {
        return isSameFloat(this.X, other.X) &&
                isSameFloat(this.Y, other.Y)
    }
}

/**
 * @category DataModelProperty
 */
export class NumberRange {
    Min: number = 0
    Max: number = 0

    constructor(Min: number = 0, Max: number = 0) {
        this.Min = Min
        this.Max = Max
    }

    clone() {
        return new NumberRange(this.Min, this.Max)
    }

    isSame(other: NumberRange) {
        return isSameFloat(this.Min, other.Min) &&
                isSameFloat(this.Max, other.Max)
    }
}

/**
 * @category DataModelProperty
 */
export class Vector3 {
    X: number = 0
    Y: number = 0
    Z: number = 0

    constructor(X: number = 0,Y: number = 0,Z: number = 0) {
        this.X = X
        this.Y = Y
        this.Z = Z
    }

    fromVec3(vec3: Vec3) {
        this.X = vec3[0]
        this.Y = vec3[1]
        this.Z = vec3[2]

        return this
    }

    toVec3(): Vec3 {
        return [this.X, this.Y, this.Z]
    }

    multiply(vec3: Vector3) {
        return new Vector3(this.X * vec3.X, this.Y * vec3.Y, this.Z * vec3.Z)
    }

    divide(vec3: Vector3) {
        return new Vector3(this.X / vec3.X, this.Y / vec3.Y, this.Z / vec3.Z)
    }

    add(vec3: Vector3) {
        return new Vector3(this.X + vec3.X, this.Y + vec3.Y, this.Z + vec3.Z)
    }

    minus(vec3: Vector3) {
        return new Vector3(this.X - vec3.X, this.Y - vec3.Y, this.Z - vec3.Z)
    }

    magnitude() {
        return Math.sqrt(this.X*this.X + this.Y*this.Y + this.Z*this.Z)
    }

    normalize() {
        const magnitude = this.magnitude()
        return this.divide(new Vector3(magnitude, magnitude, magnitude))
    }

    clone() {
        return new Vector3(this.X, this.Y, this.Z)
    }

    isSame(other: Vector3) {
        return isSameFloat(this.X, other.X) &&
                isSameFloat(this.Y, other.Y) &&
                isSameFloat(this.Z, other.Z)
    }

    lerp(other: Vector3, t: number) {
        return new Vector3(
            lerp(this.X, other.X, t),
            lerp(this.Y, other.Y, t),
            lerp(this.Z, other.Z, t),
        )
    }

    static new(X: number,Y: number,Z: number) {
        return new Vector3(X,Y,Z)
    }
}

/**
 * @category DataModelProperty
 */
export class Color3 {
    R: number = 0
    G: number = 0
    B: number = 0

    constructor(R: number = 0, G: number = 0, B: number = 0) {
        this.R = R
        this.G = G
        this.B = B
    }

    clone() {
        return new Color3(this.R, this.G, this.B)
    }
    
    isSame(other: Color3) {
        return this.R === other.R && this.G === other.G && this.B === other.B
    }

    toColor3uint8() {
        return new Color3uint8(Math.round(this.R * 255), Math.round(this.G * 255), Math.round(this.B * 255))
    }

    toArray(): Vec3 {
        return [this.R, this.G, this.B]
    }

    multiply(vec3: Color3) {
        return new Color3(this.R * vec3.R, this.G * vec3.G, this.B * vec3.B)
    }

    divide(vec3: Color3) {
        return new Color3(this.R / vec3.R, this.G / vec3.G, this.B / vec3.B)
    }

    add(vec3: Color3) {
        return new Color3(this.R + vec3.R, this.G + vec3.G, this.B + vec3.B)
    }

    minus(vec3: Color3) {
        return new Color3(this.R - vec3.R, this.G - vec3.G, this.B - vec3.B)
    }
}

/**
 * @category DataModelProperty
 */
export class Color3uint8 {
    R: number = 0
    G: number = 0
    B: number = 0

    constructor(R: number = 0, G: number = 0, B: number = 0) {
        this.R = R
        this.G = G
        this.B = B
    }

    clone() {
        return new Color3uint8(this.R, this.G, this.B)
    }

    toColor3() {
        return new Color3(this.R / 255, this.G / 255, this.B / 255)
    }

    toArray(): Vec3 {
        return [this.R, this.G, this.B]
    }
}

/**
 * @category DataModelProperty
 */
export class NumberSequenceKeypoint {
    time: number
    value: number
    envelope: number

    constructor(time: number, value: number, envelope: number = 0) {
        this.time = time
        this.value = value
        this.envelope = envelope
    }

    clone() {
        return new NumberSequenceKeypoint(this.time, this.value, this.envelope)
    }

    isSame(other: NumberSequenceKeypoint) {
        return this.time === other.time && this.value === other.value && this.envelope === other.envelope
    }
}

/**
 * @category DataModelProperty
 */
export class NumberSequence {
    keypoints: NumberSequenceKeypoint[] = []

    constructor(keypoints: NumberSequenceKeypoint[] = []) {
        this.keypoints = keypoints
    }

    clone() {
        const copy = new NumberSequence()
        for (const keypoint of this.keypoints) {
            copy.keypoints.push(keypoint.clone())
        }

        return copy
    }

    isSame(other: NumberSequence) {
        if (this.keypoints.length !== other.keypoints.length) return false

        for (let i = 0; i < this.keypoints.length; i++) {
            if (!this.keypoints[i].isSame(other.keypoints[i])) return false
        }

        return true
    }

    getLowerKey(time: number) {
        let resultKey = null

        for (const key of this.keypoints) {
            if (key.time <= time) {
                if (resultKey && resultKey.time > key.time) {
                    continue
                }
                resultKey = key
            }
        }

        return resultKey
    }

    getHigherKey(time: number) {
        let resultKey = null

        for (const key of this.keypoints) {
            if (key.time > time) {
                if (resultKey && resultKey.time < key.time) {
                    continue
                }
                resultKey = key
            }
        }

        return resultKey
    }

    getValue(time: number, seed: number) {
        const lowerKey = this.getLowerKey(time)
        const higherKey = this.getHigherKey(time)

        const lowerKeyIndex = lowerKey ? this.keypoints.indexOf(lowerKey) : 0
        const higherKeyIndex = higherKey ? this.keypoints.indexOf(higherKey) : 0

        const originalRng = new RNG(seed)

        const lowerRng = new RNG(seed + lowerKeyIndex * originalRng.nextInt())
        const higherRng = new RNG(seed + higherKeyIndex * originalRng.nextInt())

        const envelopeSignLow = lowerRng.nextInt() % 2 == 0 ? 1 : -1
        const envelopeSignHigh = higherRng.nextInt() % 2 == 0 ? 1 : -1

        const lowValue = lowerKey ? lowerKey.value + lowerKey.envelope * lowerRng.nextFloat() * envelopeSignLow : 0
        const highValue = higherKey ? higherKey.value + higherKey.envelope * higherRng.nextFloat() * envelopeSignHigh : 0

        if (higherKey && !lowerKey) {
            return highValue
        }

        if (lowerKey && !higherKey) {
            return lowValue
        }

        if (lowerKey && higherKey) {
            const keyTime = mapNum(time, lowerKey.time, higherKey.time, 0, 1)

            return (highValue - lowValue) * keyTime + lowValue
        }

        return 1
    }
}

/**
 * @category DataModelProperty
 */
export class ColorSequenceKeypoint {
    time: number
    value: Color3

    constructor(time: number, r: number, g: number, b: number) {
        this.time = time
        this.value = new Color3(r,g,b)
    }

    clone() {
        return new ColorSequenceKeypoint(this.time, this.value.R, this.value.G, this.value.B)
    }

    isSame(other: ColorSequenceKeypoint) {
        return this.time === other.time && this.value.isSame(other.value)
    }
}

/**
 * @category DataModelProperty
 */
export class ColorSequence {
    keypoints: ColorSequenceKeypoint[] = []

    static fromColor(color: Color3) {
        const colorSequence = new ColorSequence()
        colorSequence.keypoints.push(new ColorSequenceKeypoint(0, color.R, color.G, color.B))

        return colorSequence
    }

    clone() {
        const copy = new ColorSequence()
        for (const keypoint of this.keypoints) {
            copy.keypoints.push(keypoint.clone())
        }

        return copy
    }

    isSame(other: ColorSequence) {
        if (this.keypoints.length !== other.keypoints.length) return false

        for (let i = 0; i < this.keypoints.length; i++) {
            if (!this.keypoints[i].isSame(other.keypoints[i])) return false
        }

        return true
    }

    getLowerKey(time: number) {
        let resultKey = null

        for (const key of this.keypoints) {
            if (key.time <= time) {
                if (resultKey && resultKey.time > key.time) {
                    continue
                }
                resultKey = key
            }
        }

        return resultKey
    }

    getHigherKey(time: number) {
        let resultKey = null

        for (const key of this.keypoints) {
            if (key.time > time) {
                if (resultKey && resultKey.time < key.time) {
                    continue
                }
                resultKey = key
            }
        }

        return resultKey
    }

    getValue(time: number) {
        const higherKey = this.getHigherKey(time)
        const lowerKey = this.getLowerKey(time)

        if (higherKey && !lowerKey) {
            return higherKey.value
        }

        if (lowerKey && !higherKey) {
            return lowerKey.value
        }

        if (lowerKey && higherKey) {
            const keyTime = mapNum(time, lowerKey.time, higherKey.time, 0, 1)

            return (higherKey.value.minus(lowerKey.value)).multiply(new Color3(keyTime, keyTime, keyTime)).add(lowerKey.value)
        }

        return new Color3(0,0,0)
    }
}

/**
 * @category DataModelProperty
 */
export class Content {
    sourceType: number = 0 | 1 | 2 //None = 0, Uri = 1, Object = 2
    uri?: string
    object?: Instance
    externalObject?: Instance
}

/**
 * @category DataModelProperty
 */
export class CFrame {
    Position: Vec3 = [0,0,0]
    Orientation: Vec3 = [0,0,0]

    constructor(x = 0, y = 0, z = 0) {
        this.Position = [x,y,z]
    }

    static Angles(x: number, y: number, z: number): CFrame {
        return CFrame.fromEulerAngles(x,y,z,"XYZ")
    }

    clone() {
        const cloneCF = new CFrame(this.Position[0], this.Position[1], this.Position[2])
        cloneCF.Orientation = [this.Orientation[0], this.Orientation[1], this.Orientation[2]]

        return cloneCF
    }

    getTHREEMatrix() {
        /*const quat = new THREE.Quaternion().setFromEuler(new THREE.Euler(rad(this.Orientation[0]), rad(this.Orientation[1]), rad(this.Orientation[2]), "YXZ"))
        const transformMatrix = new THREE.Matrix4().makeTranslation(this.Position[0], this.Position[1], this.Position[2])

        return transformMatrix.multiply(new THREE.Matrix4().makeRotationFromQuaternion(quat))*/
        return new THREE.Matrix4().compose(new THREE.Vector3(...this.Position), new THREE.Quaternion().setFromEuler(new THREE.Euler(rad(this.Orientation[0]), rad(this.Orientation[1]), rad(this.Orientation[2]), "YXZ")), new THREE.Vector3(1,1,1))
    }

    getMatrix() {
        return this.getTHREEMatrix().elements
    }

    fromMatrix(m: Mat4x4) {
        this.Orientation = rotationMatrixToEulerAngles([
            m[0],m[1],m[2],
            m[4],m[5],m[6],
            m[8],m[9],m[10]
        ])
        this.Position = [m[12],m[13],m[14]]

        return this
    }

    fromRotationMatrix(r00: number, r01: number, r02: number, r10: number, r11: number, r12: number, r20: number, r21: number, r22: number, order: string = "YXZ") {
        /*const matrix = new Array(9)
        let i = 0
        for (let x = 0; x < 3; x++) {
            for (let y = 0; y < 3; y++) {
                matrix[x + y*3] = [
                    r00,
                    r01,
                    r02,
                    r10,
                    r11,
                    r12,
                    r20,
                    r21,
                    r22,
                ][i]
                i++
            }
        }*/

        /*this.Orientation = rotationMatrixToEulerAngles([
            r00, r01, r02,
            r10, r11, r12,
            r20, r21, r22,
        ], order)*/

        this.Orientation = rotationMatrixToEulerAngles([
            r00, r10, r20,
            r01, r11, r21,
            r02, r12, r22
        ], order)
    }

    lookVector(): Vec3 {
        const matrix = this.getTHREEMatrix()

        const pos = new THREE.Vector3()
        const quat = new THREE.Quaternion()
        const scale = new THREE.Vector3()
        matrix.decompose(pos, quat, scale)

        const lookVector = new THREE.Vector3(0,0,-1)
        lookVector.applyQuaternion(quat)

        return lookVector.toArray()
    }

    upVector(): Vec3 {
        const matrix = this.getTHREEMatrix()

        const pos = new THREE.Vector3()
        const quat = new THREE.Quaternion()
        const scale = new THREE.Vector3()
        matrix.decompose(pos, quat, scale)

        const upVector = new THREE.Vector3(0,1,0)
        upVector.applyQuaternion(quat)

        return upVector.toArray()
    }

    rightVector(): Vec3 {
        const matrix = this.getTHREEMatrix()

        const pos = new THREE.Vector3()
        const quat = new THREE.Quaternion()
        const scale = new THREE.Vector3()
        matrix.decompose(pos, quat, scale)

        const rightVector = new THREE.Vector3(1,0,0)
        rightVector.applyQuaternion(quat)

        return rightVector.toArray()
    }

    static lookAt(eye: Vec3, target: Vec3, up: Vec3 = [0,1,0]): CFrame {
        const matrix = new THREE.Matrix4().lookAt(new THREE.Vector3(...eye), new THREE.Vector3(...target), new THREE.Vector3(...up))
        const newCFrame = new CFrame()
        newCFrame.fromMatrix(matrix.elements)
        newCFrame.Position = [...eye]

        return newCFrame
    }

    static fromEulerAngles(rx: number, ry: number, rz: number, order: THREE.EulerOrder = "XYZ") {
        const matrix = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(rx, ry, rz, order))
        return new CFrame().fromMatrix(matrix.elements)
    }

    rotationOnly() {
        const copy = this.clone()
        copy.Position = [0,0,0]
        return copy
    }

    toEulerAngles(order: THREE.EulerOrder = "XYZ"): Vec3 {
        const [rx, ry, rz] = this.Orientation
        let euler = new THREE.Euler(rad(rx), rad(ry), rad(rz), "YXZ")
        euler = euler.reorder(order)
        return euler.toArray() as Vec3
    }

    inverse() {
        const inverse = this.getTHREEMatrix()
        inverse.invert()

        return new CFrame().fromMatrix(inverse.elements)
    }

    multiply(cf: CFrame) {
        const thisM = this.getTHREEMatrix()
        const cfM = cf.getTHREEMatrix()

        const newM = thisM.multiply(cfM)
        
        const newCf = new CFrame().fromMatrix(newM.elements)

        return newCf
    }

    multiplyVector(vector: Vector3) {
        const vectorCF = new CFrame(...vector.toVec3())
        const resultCF = this.multiply(vectorCF)
        const resultVector = new Vector3(...resultCF.Position)
        return resultVector
    }

    removeNaN(newValue: number = 0) {
        const newCF = new CFrame()
        newCF.Position = [
            isNaN(this.Position[0]) ? newValue : this.Position[0],
            isNaN(this.Position[1]) ? newValue : this.Position[1],
            isNaN(this.Position[2]) ? newValue : this.Position[2]
        ]
        newCF.Orientation = [
            isNaN(this.Orientation[0]) ? newValue : this.Orientation[0],
            isNaN(this.Orientation[1]) ? newValue : this.Orientation[1],
            isNaN(this.Orientation[2]) ? newValue : this.Orientation[2]
        ]

        return newCF
    }

    isSame(other: CFrame) {
        const so0 = Math.abs(this.Orientation[0]) > 179 ? Math.abs(this.Orientation[0]) : this.Orientation[0]
        const so1 = Math.abs(this.Orientation[1]) > 179 ? Math.abs(this.Orientation[1]) : this.Orientation[1]
        const so2 = Math.abs(this.Orientation[2]) > 179 ? Math.abs(this.Orientation[2]) : this.Orientation[2]

        const oo0 = Math.abs(other.Orientation[0]) > 179 ? Math.abs(other.Orientation[0]) : other.Orientation[0]
        const oo1 = Math.abs(other.Orientation[1]) > 179 ? Math.abs(other.Orientation[1]) : other.Orientation[1]
        const oo2 = Math.abs(other.Orientation[2]) > 179 ? Math.abs(other.Orientation[2]) : other.Orientation[2]

        return isSameFloat(this.Position[0], other.Position[0]) &&
                isSameFloat(this.Position[1], other.Position[1]) &&
                isSameFloat(this.Position[2], other.Position[2]) &&
                isSameFloat(so0, oo0) &&
                isSameFloat(so1, oo1) &&
                isSameFloat(so2, oo2)
    }
}

//hierarchy structs

/**
 * @category DataModel
 */
export class Connection {
    Connected = true
    _callback
    _event: Event | undefined

    constructor(callback: (...args: unknown[]) => unknown, event: Event) {
        this._callback = callback
        this._event = event
    }

    Disconnect() {
        this.Connected = false
        if (this._event) {
            this._event.Disconnect(this._callback)
        }
        this._event = undefined
    }
}

/**
 * @category DataModel
 */
export class Event {
    _callbacks: ((...args: unknown[]) => unknown)[] = []

    Connect(callback: (...args: unknown[]) => unknown) {
        this._callbacks.push(callback)
        return new Connection(callback, this)
    }

    Fire(...args: unknown[]) {
        for (let i = this._callbacks.length - 1; i >= 0; i--) {
            const callback = this._callbacks[i]
            if (!callback) return
            callback(...args)
        }
    }

    Disconnect(callback: (...args: unknown[]) => unknown) {
        const index = this._callbacks.indexOf(callback)
        if (index !== -1) {
            this._callbacks.splice(index,1)
        }
    }

    Clear() {
        for (let i = this._callbacks.length - 1; i >= 0; i--) {
            const callback = this._callbacks[i]
            if (!callback) return
            this.Disconnect(callback)
        }
        this._callbacks = []
    }
}

/**
 * @category DataModel
 */
export class Property {
    name?: string
    typeID?: number
    _value?: unknown //only to be changed by setProperty() method of Instance

    constructor(name: string | undefined = undefined, typeID: number | undefined = undefined) {
        this.name = name
        this.typeID = typeID
    }

    get value() {
        return this._value
    }
}

let lastInstanceId = 0

/**
 * @category DataModel
 */
export const AllInstances: Instance[] = []

/**
 * @category DataModel
 */
export class Instance {
    private _id: number

    /**
     * @deprecated Use .Prop("Name") instead
     */
    _name?: string //USED TO MAKE VIEWING EASIER
    className: string
    /**
     * @deprecated Do not use this directly
     */
    _properties = new Map<string,Property>()
    private _referencedBy: Instance[] = []
    private _connectionReferences: Connection[] = []
    private _children: Instance[] = []
    parent?: Instance = undefined
    destroyed: boolean = false
    private _hasWrappered: boolean = false
    wrapperInitialized: boolean = false
    //private _canGC: boolean = true

    classID?: number //dont use this to identify instance class, it is only used during file loading
    objectFormat?: number //same as above

    ChildAdded = new Event()
    ChildRemoved = new Event()
    Destroying = new Event()
    Changed = new Event()
    AncestryChanged = new Event()
    
    referencedByChanged = new Event()

    constructor(className: string, notComplete: boolean = false) {
        this._id = lastInstanceId
        lastInstanceId++

        if (!className) {
            throw new Error("Instance was not provided a className")
        }

        this.className = className

        if (!notComplete) {
            this.createWrapper()
        }

        if (FLAGS.INSTANCE_GARBAGE_COLLECT) {
            AllInstances.push(this)
        }
    }

    get id(): string {
        return "0x" + this._id.toString(16).toUpperCase()
    }

    set name(value: string) {
        this.addProperty(new Property("Name", DataType.String), value)
    }

    get name(): string {
        return this.Prop("Name") as string
    }

    get Parent(): Instance | undefined {
        return this.parent
    }

    createWrapper() {
        //instance wrappers (notice how its way shorter than the legacy part)
        const wrapper = GetWrapperForInstance(this)
        if (wrapper && !this._hasWrappered) {
            this._hasWrappered = true
            wrapper.created()
        }
        return wrapper
    }

    get w(): InstanceWrapper | undefined {
        return this.createWrapper()
    }

    addConnectionReference(connection: Connection) {
        if (!this._connectionReferences.includes(connection)) {
            this._connectionReferences.push(connection)
        }
    }

    removeConnectionReference(connection: Connection) {
        const index = this._connectionReferences.indexOf(connection)
        if (index !== -1) {
            this._connectionReferences.splice(index,1)
        }
    }

    addReferencedBy(instance: Instance) {
        if (!this._referencedBy.includes(instance)) {
            this._referencedBy.push(instance)
        }

        this.referencedByChanged.Fire()
    }

    removeReferencedBy(instance: Instance) {
        const index = this._referencedBy.indexOf(instance)
        if (index !== -1) {
            let isReferenced = false
            const properties = instance.getPropertyNames()
            for (const prop of properties) {
                if (instance.Prop(prop) === this) {
                    isReferenced = true
                }
            }
            if (!isReferenced) {
                this._referencedBy.splice(index,1)
                this.referencedByChanged.Fire()
            }
        }
    }

    getReferencedBy() {
        return [...this._referencedBy]
    }

    addProperty(property: Property, value?: unknown) {
        if (!property.name) {
            error(property)
            throw new Error("Property is missing a name")
        }

        if (!this._properties.get(property.name)) {
            this._properties.set(property.name, property)
        }

        if (value !== undefined) {
            this.setProperty(property.name, value)
        }
    }

    fixPropertyName(name: string) {
        if (this._properties.get(name)) {
            return name
        }

        switch (name) {
            case "Size": {
                name = "size"
                break
            }
            case "Shape": {
                name = "shape"
                break
            }
            case "Health": {
                name = "Health_XML"
                break
            }
            case "Color": {
                name = "Color3uint8"
                break
            }
        }

        return name
    }

    setProperty(name: string, value: unknown, supressEvents: boolean = false) {
        let property = this._properties.get(name)

        if (!property) {
            name = this.fixPropertyName(name)
            property = this._properties.get(name)
        }

        if (property) {
            //special stuff
            const valueOld = property.value as Instance
            if (property.typeID === DataType.CFrame && property.value && value) {
                const valueCF = value as CFrame
                if (isNaN(valueCF.Position[0]) || isNaN(valueCF.Position[1]) || isNaN(valueCF.Position[2])) {
                    error(value)
                    throw new Error("CFrame position can't contain NaN value")
                }
                if (isNaN(valueCF.Orientation[0]) || isNaN(valueCF.Orientation[1]) || isNaN(valueCF.Orientation[2])) {
                    error(value)
                    throw new Error("CFrame orientation can't contain NaN value")
                }
            }
            if (name === "Name") {
                this._name = value as string
            }
            if (FLAGS.SEARCH_FOR_STRING) {
                if (property.typeID === DataType.String || property.typeID === DataType.Bytecode || property.typeID === DataType.SharedString) {
                    if (value && (value as string).toLowerCase().includes(FLAGS.SEARCH_FOR_STRING)) {
                        log(true, this.GetFullName())
                        log(true, value)
                        if ((value as string).length > 10000) {
                            download(this.GetFullName(), value as string)
                        }
                    }
                }
            }

            property._value = value

            //special stuff
            if (property.typeID === DataType.Referent && valueOld) {
                valueOld.removeReferencedBy(this)
            }
            if (property.typeID === DataType.Referent && property.value) {
                const valueInstance = property.value as Instance
                valueInstance.addReferencedBy(this)
            }
            if (!supressEvents) this.Changed.Fire(name)
        } else {
            warn(true, `Property with name ${name} was not found in ${this.GetFullName()}`)
        }
    }

    HasProperty(name: string) {
        name = this.fixPropertyName(name)

        return !!(this._properties.get(name))
    }

    /**
     * Returns the value of a property
     * @param name Name of property
     * @returns Property's value
     * 
     * @throws When property doesn't exist, PropOrDefault is a safer alternative
     */
    Property(name: string): unknown {
        let property = this._properties.get(name)

        if (property) return property.value

        name = this.fixPropertyName(name)
        property = this._properties.get(name)

        if (property) return property.value


        switch (name) {
            case "Position":
                {
                    const cf = this.Prop("CFrame") as CFrame
                    const pos = cf.Position
                    return new Vector3(pos[0], pos[1], pos[2])
                    break
                }
            case "Color3uint8":
                {
                    if (this.HasProperty("BrickColor")) {
                        const hex = BrickColors[this.Prop("BrickColor") as number]
                        const rgb = hexToRgb(hex)
                        const color3uint8 = new Color3uint8(rgb?.r, rgb?.g, rgb?.b)
                        color3uint8.R *= 255
                        color3uint8.G *= 255
                        color3uint8.B *= 255
                        return color3uint8
                    }
                    break
                }
            default:
                {
                    if (this.className === "Decal" && name === "Texture") {
                        if (this.HasProperty("TextureContent")) {
                            return (this.Prop("TextureContent") as Content).uri
                        } else if (this.HasProperty("ColorMapContent")) {
                            return (this.Prop("ColorMapContent") as Content).uri
                        }
                    } else if (name.includes("Id") || name.includes("ID")) {
                        const contentVersion = name.replace("Id", "Content").replace("ID","Content")
                        if (this.HasProperty(contentVersion)) {
                            const content = this.Prop(contentVersion) as Content
                            return content.uri
                        }
                        break
                    }
                }
        }


        if (!property) {
            error(this)
            throw new Error(`Property: ${name} does not exist`)
        }
    }

    /**
     * Returns the value of a property
     * @param name Name of property
     * @returns Property's value
     * 
     * @throws When property doesn't exist, PropOrDefault is a safer alternative
     */
    Prop(name: string): unknown {
        return this.Property(name)
    }

    PropOrDefault(name: string, def: unknown) {
        return this.HasProperty(name) ? this.Prop(name) : def
    }

    PropertyType(name: string): number | undefined {
        return this._properties.get(name)?.typeID
    }

    getPropertyNames() {
        return Array.from(this._properties.keys())
    }

    setParent(instance: Instance | undefined | null, fireEvents: boolean = true) {
        if (!instance) {
            instance = undefined
        }

        if (instance?.destroyed) {
            throw new Error("Cannot set parent of instance to a destroyed instance")
        }

        if (this.parent) {
            const index = this.parent._children.indexOf(this)
            if (index !== -1) {
                this.parent._children.splice(index, 1)
            }
        }

        const originalParent = this.parent

        this.parent = instance

        //special logic
        if (originalParent && originalParent !== instance) {
            originalParent.ChildRemoved.Fire(this)
            originalParent.AncestryChanged.Fire(this)
        }

        //finalize
        if (instance) {
            instance._children.push(this)
        }

        //events
        if (fireEvents) {
            if (instance) {
                instance.ChildAdded.Fire(this)
                instance.AncestryChanged.Fire(this, instance)
            }
            this.AncestryChanged.Fire(this, instance)
        }
    }

    Destroy() {
        //disconnect all connections created by instance
        for (const connection of this._connectionReferences) {
            connection.Disconnect()
        }
        this._connectionReferences = []

        this.Destroying.Fire(this)

        this.ChildAdded.Clear()
        this.ChildRemoved.Clear()
        this.Destroying.Clear()
        this.Changed.Clear()
        this.AncestryChanged.Clear()

        this.referencedByChanged.Clear()

        this.setParent(null)

        //destroy all children
        for (const child of this.GetChildren()) {
            child.Destroy()
        }

        //set all properties to null
        for (const property of this.getPropertyNames()) {
            this.setProperty(property, null)
        }

        //remove all references to instance
        for (const instance of this.getReferencedBy()) {
            for (const propertyName of instance.getPropertyNames()) {
                if (instance.Property(propertyName) === this) {
                    instance.setProperty(propertyName, null)
                }
            }
        }
        this._referencedBy = []

        if (FLAGS.INSTANCE_GARBAGE_COLLECT) {
            if (AllInstances.length === 1) {
                AllInstances.splice(1,1)
            } else if (AllInstances.length > 1) {
                const index = AllInstances.indexOf(this)
                const last = AllInstances[AllInstances.length - 1]

                AllInstances[index] = last
                AllInstances.splice(AllInstances.length - 1, 1)
            }
        }

        this.destroyed = true
    }

    GetFullName(): string {
        if (this.parent && this.parent.className !== "DataModel") {
            return this.parent.GetFullName() + "." + this.name
        } else {
            return this.name || "null"
        }
    }

    /**
     * @returns A reference to Instance._children, dangerous since the array can be modified by the Instance due to setParent and similar
     */
    GetChildrenDangerous(): Instance[] {
        return this._children
    }

    GetChildren(): Instance[] { //It is done like this so setting parents doesnt mess up the list
        return [...this._children]
    }

    GetDescendants(): Instance[] {
        const toCheck = this.GetChildren()
        const descendants: Instance[] = [...toCheck]

        while (toCheck.length > 0) {
            const child = toCheck.pop()!
            const children = child.GetChildrenDangerous() //we can use dangerous here since we do ... on it anyway ourselves
            toCheck.push(...children)
            descendants.push(...children)
        }

        return descendants
    }

    FindFirstChild(name: string): Instance | undefined {
        for (const child of this.GetChildren()) {
            if (child.Property("Name") === name) {
                return child
            }
        }
    }

    FindFirstDescendant(name: string): Instance | undefined {
        for (const child of this.GetDescendants()) {
            if (child.Property("Name") === name) {
                return child
            }
        }
    }

    Child(name: string): Instance | undefined {
        return this.FindFirstChild(name)
    }

    FindFirstChildOfClass(className: string): Instance | undefined {
        for (const child of this._children) {
            if (child.className === className) {
                return child
            }
        }
    }

    FindLastChildOfClass(className: string): Instance | undefined {
        let lastChild: Instance | undefined = undefined

        for (const child of this._children) {
            if (child.className === className) {
                lastChild = child
            }
        }

        return lastChild
    }

    /**
     * IMPORTANT: Only works properly for instances with an InstanceWrapper
     * @param className 
     * @returns 
     */
    IsA(className: string): boolean {
        if (this.className === className) return true

        const wrapper = this.w
        if (wrapper) {
            return wrapper.IsA(className)
        }

        return false
    }

    IsDescendantOf(instance: Instance) {
        let next = this.parent
        while (next) {
            if (next === instance) {
                return true
            }

            next = next.parent
        }

        return false
    }

    preRender() {
        const wrapper = GetWrapperForInstance(this)
        if (wrapper) {
            wrapper.preRender()
        }

        for (const child of this.GetChildren()) {
            child.preRender()
        }
    }
}

class INST {
    classID!: number //u32
    className!: string //string
    objectFormat!: number //u8
    instanceCount!: number //u32
    referents!: number[] //i32[]

    clone() {
        const copy = new INST()
        copy.classID = this.classID
        copy.className = this.className
        copy.objectFormat = this.objectFormat
        copy.instanceCount = this.instanceCount
        copy.referents = []
        for (const referent of this.referents) {
            copy.referents.push(referent)
        }
        return copy
    }
}

class PROP {
    classID!: number //u32
    propertyName!: string //string
    typeID!: number //u8
    values: unknown[] = []

    clone() {
        const copy = new PROP()
        copy.classID = this.classID
        copy.propertyName = this.propertyName
        copy.typeID = this.typeID
        copy.values = []
        for (const value of this.values) {
            switch (this.typeID) {
                case DataType.UDim:
                case DataType.UDim2:
                case DataType.Ray:
                case DataType.Vector2:
                case DataType.Vector3:
                case DataType.Color3:
                case DataType.Color3uint8:
                case DataType.CFrame:
                case DataType.NumberRange:
                case DataType.NumberSequence:
                case DataType.ColorSequence:
                    copy.values.push((value as {clone: () => unknown}).clone())
                    break
                default:
                    copy.values.push(value)
                    break
            }
        }
        return copy
    }
}

class PRNT {
    instanceCount = 0
    childReferents: number[] = []
    parentReferents: number[] = []

    clone() {
        const copy = new PRNT()
        copy.instanceCount = this.instanceCount
        for (const childReferent of this.childReferents) {
            copy.childReferents.push(childReferent)
        }
        for (const parentReferent of this.parentReferents) {
            copy.parentReferents.push(parentReferent)
        }
        return copy
    }
}

/**
 * Obtained from a call to API.Asset.GetRBX()
 * @category DataModel
 */
export class RBX {

    classCount = 0 //i32
    instanceCount = 0 //i32

    meta = new Map<string,string>() //Map<string,string>
    sstr = new Map<number[],string>() //Map<MD5,string>
    sstrArr: string[] = []
    instArray: INST[] = [] //INST[]
    propArray: PROP[] = [] //PROP[]
    prnt = new PRNT() //PRNT

    //not based on file format
    classIDtoINST = new Map()
    dataModel = new Instance("DataModel")
    treeGenerated = false
    xmlString?: string

    get instances() {
        return this.dataModel.GetChildren()
    }

    constructor() {
        this.reset()
    }

    reset() {
        this.classCount = 0
        this.instanceCount = 0

        this.meta = new Map()
        this.sstr = new Map()
        this.instArray = []
        this.propArray = []
        this.prnt = new PRNT()

        this.classIDtoINST = new Map()

        this.dataModel = new Instance("DataModel")
        this.dataModel.name = "root"
        this.dataModel.classID = -1 //TODO: is this true? a bit hard to test
        this.dataModel.objectFormat = 0
    }

    clone() { //DOES NOT COPY (DATAMODEL or treeGenerated), instead regenerate tree
        const copy = new RBX()
        copy.classCount = this.classCount
        copy.instanceCount = this.instanceCount
        
        for (const key of this.meta.keys()) {
            const value = this.meta.get(key)
            if (value) {
                copy.meta.set(key, value)
            }
        }

        for (const key of this.sstr.keys()) {
            const value = this.sstr.get(key)
            if (value) {
                copy.sstr.set(key, value)
            }
        }

        for (const inst of this.instArray) {
            copy.instArray.push(inst.clone())
            copy.classIDtoINST.set(inst.classID, inst)
        }

        for (const prop of this.propArray) {
            copy.propArray.push(prop.clone())
        }

        copy.prnt = this.prnt.clone()

        copy.xmlString = this.xmlString

        return copy
    }

    readMETA(chunkView: RBXSimpleView) {
        const entriesCount = chunkView.readUint32()
        for (let i = 0; i < entriesCount; i++) {
            const metaKey = chunkView.readUtf8String()
            const metaValue = chunkView.readUtf8String()

            this.meta.set(metaKey, metaValue)
        }
    }

    readSSTR(chunkView: RBXSimpleView) {
        const version = chunkView.readUint32() //always 0
        if (version !== 0) {
            throw new Error("Unexpected SSTR version")
        }

        const sharedStringCount = chunkView.readUint32()
        for (let i = 0; i < sharedStringCount; i++) {
            const md5 = [chunkView.readUint32(), chunkView.readUint32(), chunkView.readUint32(), chunkView.readUint32()]
            const str = chunkView.readUtf8String()

            this.sstrArr.push(str)
            this.sstr.set(md5, str)
        }
    }

    readINST(chunkView: RBXSimpleView) {
        const inst = new INST()

        inst.classID = chunkView.readUint32()
        inst.className = chunkView.readUtf8String()
        inst.objectFormat = chunkView.readUint8()
        inst.instanceCount = chunkView.readUint32()
        const referents = readReferents(inst.instanceCount, chunkView)
        inst.referents = referents
        //servicemarkes could be read here but is useless and a waste of time

        this.instArray.push(inst)
        this.classIDtoINST.set(inst.classID, inst)
    }

    readPROP(chunkView: RBXSimpleView) {
        const prop = new PROP()
        prop.classID = chunkView.readUint32()
        prop.propertyName = chunkView.readUtf8String()
        prop.typeID = chunkView.readUint8()

        //read values
        const valuesLength = this.classIDtoINST.get(prop.classID).instanceCount

        switch (prop.typeID) {
            case DataType.Bytecode:
            case DataType.String:
                {
                    let totalRead = 0
                    while (totalRead < valuesLength) {
                        //as buffer
                        //const originalStart = chunkView.viewOffset
                        //const length = chunkView.readUint32()
                        //const buffer = chunkView.buffer.slice(chunkView.viewOffset, chunkView.viewOffset + length - 1)
                        //chunkView.viewOffset = originalStart

                        if (StringBufferProperties.includes(prop.propertyName) && !FLAGS.SEARCH_FOR_STRING) {
                            const length = chunkView.readUint32()
                            prop.values.push(chunkView.buffer.slice(chunkView.viewOffset, chunkView.viewOffset + length - 1))
                            chunkView.viewOffset += length
                            //prop.values.push(chunkView.buffer)
                        } else {
                            prop.values.push(chunkView.readUtf8String())
                            /*const str = prop.values[prop.values.length - 1] as string
                            if (str.includes("looks/")) {
                                console.log(prop.values[prop.values.length - 1])
                                console.log(buffer)
                                saveByteArray([buffer as BlobPart], str.slice(0, 6))
                            }*/
                        }
                        totalRead++
                    }
                    break
                }
            case DataType.Bool:
                {
                    for (let i = 0; i < valuesLength; i++) {
                        prop.values.push(chunkView.readUint8() > 0)
                    }
                    break
                }
            case DataType.Int32:
                {
                    const nums = chunkView.readInterleaved32(valuesLength, false) as number[]
                    //untransform
                    for (let i = 0; i < nums.length; i++) {
                        nums[i] = untransformInt32(nums[i])
                        prop.values.push(nums[i])
                    }
                    
                    break
                }
            case DataType.Float32:
                {
                    const nums = chunkView.readInterleaved32(valuesLength, false, "readFloat32")
                    
                    for (let i = 0; i < nums.length; i++) {
                        prop.values.push(nums[i])
                    }

                    break
                }
            case DataType.Float64:
                {
                    for (let i = 0; i < valuesLength; i++) {
                        prop.values.push(chunkView.readFloat64())
                    }
                    break
                }
            case DataType.UDim:
                {
                    const scales = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const offsets = chunkView.readInterleaved32(valuesLength, false) as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        const udim = new UDim()
                        udim.Scale = scales[i]
                        udim.Offset = untransformInt32(offsets[i])
                        prop.values.push(udim)
                    }

                    break
                }
            case DataType.UDim2:
                {
                    const scalesX = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const scalesY = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const offsetsX = chunkView.readInterleaved32(valuesLength, false) as number[]
                    const offsetsY = chunkView.readInterleaved32(valuesLength, false) as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        const udim = new UDim2()
                        udim.X.Scale = scalesX[i]
                        udim.Y.Scale = scalesY[i]
                        udim.X.Offset = untransformInt32(offsetsX[i])
                        udim.Y.Offset = untransformInt32(offsetsY[i])
                        prop.values.push(udim)
                    }

                    break
                }
            case DataType.Ray: //TODO: NOT TESTED
                {
                    for (let i = 0; i < valuesLength; i++) {
                        const ray = new Ray()
                        ray.Origin = [chunkView.readNormalFloat32(), chunkView.readNormalFloat32(), chunkView.readNormalFloat32()]
                        ray.Direction = [chunkView.readNormalFloat32(), chunkView.readNormalFloat32(), chunkView.readNormalFloat32()]
                        prop.values.push(ray)
                    }
                    break
                }
            case DataType.BrickColor:
                {
                    const values = chunkView.readInterleaved32(valuesLength, false, "readUint32")
                    for (const value of values) {
                        prop.values.push(value)
                    }
                    break
                }
            case DataType.Color3: //TODO: NOT TESTED
                {
                    const xValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const yValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const zValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        const vector3 = new Color3()
                        vector3.R = xValues[i]
                        vector3.G = yValues[i]
                        vector3.B = zValues[i]
                        prop.values.push(vector3)
                    }
                    break
                }
            case DataType.Vector2:
                {
                    const xValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const yValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        const vector2 = new Vector2()
                        vector2.X = xValues[i]
                        vector2.Y = yValues[i]
                        prop.values.push(vector2)
                    }
                    break
                }
            case DataType.Vector3:
                {
                    const xValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const yValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const zValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        const vector3 = new Vector3()
                        vector3.X = xValues[i]
                        vector3.Y = yValues[i]
                        vector3.Z = zValues[i]
                        prop.values.push(vector3)
                    }
                    break
                }
            case DataType.CFrame:
                {
                    const cframes = []

                    for (let i = 0; i < valuesLength; i++) { //rotation array
                        const cframe = new CFrame()

                        const id = chunkView.readUint8()
                        if (id === 0) {
                            const matrix = new Array(9)
                            for (let x = 0; x < 3; x++) {
                                for (let y = 0; y < 3; y++) {
                                    matrix[x + y*3] = chunkView.readNormalFloat32()
                                }
                            }

                            cframe.Orientation = rotationMatrixToEulerAngles(matrix)
                            //cframe.Orientation[3] = matrix
                        } else {
                            const orientationTable: {[K in number]: Vec3} = { //TODO: double check this
                                0x02: [0, 0, 0],
                                0x14: [0, 180, 0],
                                0x03: [90, 0, 0],
                                0x15: [-90, -180, 0],
                                0x05: [0, 180, 180],
                                0x17: [0, 0, 180],
                                0x06: [-90, 0, 0],
                                0x18: [90, 180, 0],
                                0x07: [0, 180, 90],
                                0x19: [0, 0, -90],
                                0x09: [0, 90, 90],
                                0x1b: [0, -90, -90],
                                0x0a: [0, 0, 90],
                                0x1c: [0, -180, -9],
                                0x0c: [0, -90, 90],
                                0x1e: [0, 90, -90],
                                0x0d: [-90, -90, 0],
                                0x1f: [90, 90, 0],
                                0x0e: [0, -90, 0],
                                0x20: [0, 90, 0],
                                0x10: [90, -90, 0],
                                0x22: [-90, 90, 0],
                                0x11: [0, 90, 180],
                                0x23: [0, -90, 180],
                            }

                            cframe.Orientation = orientationTable[id]
                        }

                        cframes.push(cframe)
                    }

                    const xValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const yValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]
                    const zValues = chunkView.readInterleaved32(valuesLength, false, "readFloat32") as number[]

                    for (let i = 0; i < valuesLength; i++) {
                        cframes[i].Position = [xValues[i], yValues[i], zValues[i]]
                        prop.values.push(cframes[i])
                    }
                    break
                }
            case DataType.Enum: //TODO: NOT TESTED
                {
                    const values = chunkView.readInterleaved32(valuesLength, false, "readUint32") as number[]

                    for (const val of values) {
                        prop.values.push(val)
                    }
                    break
                }
            case DataType.Referent: //Note: Referents become native references when tree is generated
                {
                    const referents = readReferents(valuesLength, chunkView)

                    for (const referent of referents) {
                        prop.values.push(referent)
                    }
                    break
                }
            case DataType.NumberSequence:
                {
                    for (let i = 0; i < valuesLength; i++) {
                        const length = chunkView.readUint32()

                        const numberSequence = new NumberSequence()

                        for (let j = 0; j < length; j++) {
                            numberSequence.keypoints.push(new NumberSequenceKeypoint(chunkView.readNormalFloat32(), chunkView.readNormalFloat32(), chunkView.readNormalFloat32()))
                        }

                        prop.values.push(numberSequence)
                    }
                    break
                }
            case DataType.ColorSequence:
                {
                    for (let i = 0; i < valuesLength; i++) {
                        const length = chunkView.readUint32()

                        const colorSequence = new ColorSequence()

                        for (let j = 0; j < length; j++) {
                            colorSequence.keypoints.push(new ColorSequenceKeypoint(chunkView.readNormalFloat32(), chunkView.readNormalFloat32(), chunkView.readNormalFloat32(), chunkView.readNormalFloat32()))
                            chunkView.readNormalFloat32()
                        }

                        prop.values.push(colorSequence)
                    }
                    break
                }
            case DataType.NumberRange:
                {
                    for (let i = 0; i < valuesLength; i++) {
                        prop.values.push(new NumberRange(chunkView.readNormalFloat32(), chunkView.readNormalFloat32()))
                    }
                    break
                }
            case DataType.Color3uint8: //TODO: NOT TESTED
                {
                    const rs = []
                    const gs = []

                    for (let i = 0; i < valuesLength; i++) {
                        rs.push(chunkView.readUint8())
                    }
                    for (let i = 0; i < valuesLength; i++) {
                        gs.push(chunkView.readUint8())
                    }
                    for (let i = 0; i < valuesLength; i++) {
                        const color = new Color3uint8()
                        color.R = rs[i]
                        color.G = gs[i]
                        color.B = chunkView.readUint8()

                        prop.values.push(color)
                    }
                    break
                }
            case DataType.Int64:
                {
                    const nums = chunkView.readInterleaved32(valuesLength, false, "readInt64", 8) as bigint[]
                    //untransform
                    for (let i = 0; i < nums.length; i++) {
                        nums[i] = untransformInt64(nums[i])
                        prop.values.push(nums[i])
                    }

                    break
                }
            case DataType.SharedString:
                {
                    const nums = chunkView.readInterleaved32(valuesLength, false, "readUint32") as number[]
                    
                    for (const num of nums) {
                        prop.values.push(num)
                    }

                    break
                }
            case DataType.Content:
                {
                    const sourceTypes = chunkView.readInterleaved32(valuesLength, false, "readUint32") as number[]

                    const uriCount = chunkView.readUint32()
                    const uris = []
                    for (let i = 0; i < uriCount; i++) {
                        uris.push(chunkView.readUtf8String())
                    }

                    //const objectCount = chunkView.readUint32()
                    //const objects = readReferents(objectCount, chunkView)

                    //const externalObjectCount = chunkView.readUint32()
                    //const externalObjects = readReferents(externalObjectCount, chunkView)

                    let uriIndex = 0
                    //let objectIndex = 0
                    //let externalObjectIndex = 0

                    for (let i = 0; i < valuesLength; i++) {
                        const content = new Content()
                        content.sourceType = sourceTypes[i]

                        //i think the enums are wrong here...
                        switch (content.sourceType) { //2 - Uri, 0 - Object/None,
                            case 0: //None
                                
                                break
                            case 1: //Uri
                            case 2: //Object
                                content.uri = uris[uriIndex]
                                uriIndex += 1
                                break
                        }

                        prop.values.push(content)
                    }

                    break
                }
            default:
                warn(false, `Unknown property type ${prop.typeID} in property ${prop.propertyName}`)
        }

        //if (prop.values.length > 0) {
            this.propArray.push(prop)
        //}
    }

    readPRNT(chunkView: RBXSimpleView) {
        const version = chunkView.readUint8()
        if (version !== 0) {
            throw new Error("Unexpected PRNT version")
        }

        const prnt = new PRNT()

        prnt.instanceCount = chunkView.readUint32()
        prnt.childReferents = readReferents(prnt.instanceCount, chunkView)
        prnt.parentReferents = readReferents(prnt.instanceCount, chunkView)
        this.prnt = prnt
    }

    getChunkBuffer(view: RBXSimpleView, compressedLength: number, uncompressedLength: number) {
        //compressed
        if (compressedLength !== 0) {
            const isZSTD = view.readUint32() == 4247762216
            view.viewOffset -= 4
            const isLZ4 = !isZSTD

            const compressedByteArray = view.buffer.slice(view.viewOffset, view.viewOffset + compressedLength)

            if (isZSTD) { //ZSTD
                const decompressedData = fzstd.decompress(new Uint8Array(compressedByteArray)).buffer
                return decompressedData.slice(12)
            } else if (isLZ4) { //LZ4
                //const uncompressed = Buffer.alloc(uncompressedLength)

                //const compressedByteArray = view.buffer.slice(view.viewOffset, view.viewOffset + compressedLength)
                //const compressedIntArray = new Uint8Array(compressedByteArray) as Buffer<ArrayBufferLike>

                ///*const uncompressedSize = */LZ4.decodeBlock(compressedIntArray, uncompressed)
                
                //return uncompressed.buffer
                
                return LZ4.decompress(compressedByteArray, uncompressedLength)
            }
        }

        //uncompressed
        return view.buffer.slice(view.viewOffset, view.viewOffset + uncompressedLength)
    }

    addItem(propertyToReferent: Map<Property,string>, item: Element, itemParent?: Instance) {
        const instance = new Instance(item.getAttribute("class") || "null", true)

        const properties = item.querySelectorAll(":scope > Properties > *")
        for (const propertyNode of properties) {
            switch (propertyNode.nodeName) {
                case "Content":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.Content

                        instance.addProperty(property)

                        const childElement = propertyNode.querySelector(":scope > *")

                        if (childElement) {
                            if (childElement.nodeName === "null") {
                                instance.setProperty(property.name, "")
                            } else {
                                instance.setProperty(property.name, childElement.textContent)
                            }
                        } else {
                            instance.setProperty(property.name, "")
                        }
                        break
                    }
                case "string":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.String

                        instance.addProperty(property)
                        instance.setProperty(property.name, propertyNode.textContent)
                        break
                    }
                case "bool":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.Bool

                        instance.addProperty(property)
                        instance.setProperty(property.name, propertyNode.textContent.toLowerCase() === "true")
                        break
                    }
                case "CoordinateFrame":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.CFrame

                        instance.addProperty(property)

                        const cframeDesc: {[K in string]: number} = {}

                        const childElements = propertyNode.querySelectorAll(":scope > *")

                        const cframe = new CFrame()
                        for (const element of childElements) {
                            cframeDesc[element.nodeName] = Number(element.textContent)
                        }

                        const matrix = new Array(9)
                        let i = 0
                        for (let x = 0; x < 3; x++) {
                            for (let y = 0; y < 3; y++) {
                                matrix[x + y*3] = [
                                    cframeDesc.R00,
                                    cframeDesc.R01,
                                    cframeDesc.R02,
                                    cframeDesc.R10,
                                    cframeDesc.R11,
                                    cframeDesc.R12,
                                    cframeDesc.R20,
                                    cframeDesc.R21,
                                    cframeDesc.R22,
                                ][i]
                                i++
                            }
                        }

                        cframe.Orientation = rotationMatrixToEulerAngles(matrix)
                        cframe.Position = [cframeDesc.X, cframeDesc.Y, cframeDesc.Z]

                        instance.setProperty(property.name, cframe)

                        break
                    }
                case "Vector2":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.Vector2

                        instance.addProperty(property)

                        const childElements = propertyNode.querySelectorAll(":scope > *")

                        const position = new Vector2()
                        for (const element of childElements) {
                            position[element.nodeName as ("X" | "Y")] = Number(element.textContent)
                        }

                        instance.setProperty(property.name, position)

                        break
                    }
                case "Vector3":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.Vector3

                        instance.addProperty(property)

                        const childElements = propertyNode.querySelectorAll(":scope > *")

                        const position = new Vector3()
                        for (const element of childElements) {
                            position[element.nodeName as ("X" | "Y" | "Z")] = Number(element.textContent)
                        }

                        instance.setProperty(property.name, position)

                        break
                    }
                case "token":
                    {
                        const property = new Property()
                        property.name = propertyNode.getAttribute("name") || "null"
                        property.typeID = DataType.Enum

                        instance.addProperty(property)
                        instance.setProperty(property.name, Number(propertyNode.textContent))

                        break
                    }
                case "Color3":
                    {
                        const color3 = new Color3()

                        const childElements = propertyNode.querySelectorAll(":scope > *")

                        if (childElements.length < 3) {
                            const intColor = Number(propertyNode.textContent)
                            const colorRGB = intToRgb(intColor)
                            color3.R = colorRGB.R / 255
                            color3.G = colorRGB.G / 255
                            color3.B = colorRGB.B / 255
                        } else {
                            for (const element of childElements) {
                                color3[element.nodeName as ("R" | "G" | "B")] = Number(element.textContent)
                            }
                        }

                        instance.addProperty(new Property(propertyNode.getAttribute("name") || "null", DataType.Color3), color3)
                        break
                    }
                case "Color3uint8":
                    {
                        const color3uint8 = new Color3uint8()

                        const intColor = Number(propertyNode.textContent)
                        const colorRGB = intToRgb(intColor)
                        color3uint8.R = colorRGB.R
                        color3uint8.G = colorRGB.G
                        color3uint8.B = colorRGB.B

                        instance.addProperty(new Property(propertyNode.getAttribute("name") || "null", DataType.Color3uint8), color3uint8)
                        break
                    }
                case "int": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.Int32

                    instance.addProperty(property)
                    instance.setProperty(property.name, Number(propertyNode.textContent))
                    break
                }
                case "int64": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.Int64

                    instance.addProperty(property)
                    instance.setProperty(property.name, BigInt(propertyNode.textContent))
                    break
                }
                case "float": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.Float32

                    instance.addProperty(property)
                    instance.setProperty(property.name, Number(propertyNode.textContent))
                    break
                }
                case "Ref": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.Referent

                    instance.addProperty(property)
                    instance.setProperty(property.name, undefined)
                    propertyToReferent.set(property, propertyNode.textContent)
                    break
                }
                case "double": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.Float64

                    instance.addProperty(property)
                    instance.setProperty(property.name, Number(propertyNode.textContent))
                    break
                }
                case "NumberRange": {
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.NumberRange

                    const values = propertyNode.textContent.split(" ")
                    const numValues = values.length >= 2 ? [Number(values[0]), Number(values[1])] : [1,1]

                    instance.addProperty(property)
                    instance.setProperty(property.name, new NumberRange(numValues[0], numValues[1]))

                    break
                }
                case "NumberSequence": {
                    //time, value, envelope
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.NumberSequence

                    const values = propertyNode.textContent.split(" ")

                    const numberSequence = new NumberSequence()

                    for (let i = 0; i < Math.floor(values.length / 3); i++) {
                        const time = Number(values[i*3 + 0])
                        const value = Number(values[i*3 + 1])
                        const envelope = Number(values[i*3 + 2])

                        const keypoint = new NumberSequenceKeypoint(time, value, envelope)
                        numberSequence.keypoints.push(keypoint)
                    }

                    instance.addProperty(property)
                    instance.setProperty(property.name, numberSequence)

                    break
                }
                case "ColorSequence": {
                    //time, value, envelope
                    const property = new Property()
                    property.name = propertyNode.getAttribute("name") || "null"
                    property.typeID = DataType.ColorSequence

                    const values = propertyNode.textContent.split(" ")

                    const colorSequence = new ColorSequence()

                    for (let i = 0; i < Math.floor(values.length / 5); i++) {
                        const time = Number(values[i*5 + 0])
                        const r = Number(values[i*5 + 1])
                        const g = Number(values[i*5 + 2])
                        const b = Number(values[i*5 + 3])
                        //const envelope = Number(values[i*5 + 4])

                        const keypoint = new ColorSequenceKeypoint(time, r, g, b)
                        colorSequence.keypoints.push(keypoint)
                    }

                    instance.addProperty(property)
                    instance.setProperty(property.name, colorSequence)

                    break
                }
                default: {
                    warn(false, `XML: Can't parse type "${propertyNode.nodeName}" in "${propertyNode.getAttribute("name") || "null"}"`)
                    //console.warn(propertyNode)
                }
            }
        }

        if (itemParent) {
            instance.setParent(itemParent)
        } else {
            instance.setParent(this.dataModel)
        }
        
        return instance
    }

    fromXML(xml: Document) { //TODO: figure out how to do this accurately https://dom.rojo.space/xml.html
        warn(false, "Parsing RBX xml file, the result may not be accurate")
        warn(false, xml)

        const itemParentMap = new Map<Element,Instance>()
        const propertyToReferent = new Map<Property,string>()
        const referentMap = new Map<string,Instance>()

        let currentItems: Element[] | NodeListOf<Element> = xml.querySelectorAll(":scope > Item")
        while (currentItems.length > 0) {
            const newCurrentItems = []

            for (const item of currentItems) {
                const instance = this.addItem(propertyToReferent, item, itemParentMap.get(item))
                const referent = item.getAttribute("referent") || "null"
                referentMap.set(referent, instance)

                const itemChildren = item.querySelectorAll(":scope > Item")
                for (const itemChild of itemChildren) {
                    itemParentMap.set(itemChild, instance)
                    newCurrentItems.push(itemChild)
                }
            }

            currentItems = newCurrentItems
        }

        //set referent properties
        for (const child of this.dataModel.GetDescendants()) {
            for (const propertyName of child.getPropertyNames()) {
                const property = child._properties.get(propertyName)
                if (property && property.typeID === DataType.Referent) {
                    const referent = propertyToReferent.get(property)

                    if (referent) {
                        const instance = referentMap.get(referent)
                        child.setProperty(propertyName, instance)
                    }
                }
            }

            child.createWrapper()
        }

        this.treeGenerated = true
    }

    fromBuffer(buffer: ArrayBuffer) {
        this.reset()

        const view = new RBXSimpleView(buffer)

        // FILE HEADER

        //verify magic
        const readMagic = view.readUtf8String(magic.length)
        if (readMagic !== magic) {
            if (readMagic === xmlMagic) {
                const xmlString = new TextDecoder("utf-8").decode(buffer)
                const xml = new DOMParser().parseFromString(xmlString, "text/xml")
                this.xmlString = xmlString
                this.fromXML(xml)
                return
            } else {
                error(buffer)
                throw new Error("Not a valid file, missing magic")
            }
        }

        //skip signature
        view.viewOffset += 6

        //skip version (always 0, u16)
        view.viewOffset += 2

        this.classCount = view.readInt32()
        this.instanceCount = view.readInt32()

        //skip padding
        view.viewOffset += 8

        log(false, `FILESIZE: ${buffer.byteLength}, CLASSCOUNT: ${this.classCount}, INSTCOUNT: ${this.instanceCount}`)

        //CHUNKS
        let timeout = 0
        let foundEnd = false
        while (!foundEnd) {
            const chunkName = view.readUtf8String(4)
            const compressedLength = view.readUint32()
            const uncompressedLength = view.readUint32()

            view.viewOffset += 4 //skip unused

            const chunkBuffer = this.getChunkBuffer(view, compressedLength, uncompressedLength)

            view.lock()

            const chunkView = new RBXSimpleView(chunkBuffer)

            //console.log(`CHUNK: ${chunkName}, USIZE: ${uncompressedLength}, CSIZE: ${compressedLength}`)
            //console.log(chunkBuffer)

            /*
            if (chunkName == "PRNT") {
                saveByteArray([chunkBuffer], `${chunkName}.dat`)
            }
            */

            switch (chunkName) {
                case "META":
                    {
                        this.readMETA(chunkView)
                        break
                    }
                case "SSTR":
                    {
                        this.readSSTR(chunkView)
                        break
                    }
                case "INST":
                    {
                        this.readINST(chunkView)
                        break
                    }
                case "PROP":
                    {
                        this.readPROP(chunkView)
                        break
                    }
                case "PRNT":
                    {
                        this.readPRNT(chunkView)
                        break
                    }
                case "END\0":
                    foundEnd = true    
                    break
                default:
                    warn(false, "Unknown chunk found: " + chunkName)
                    break
            }

            view.unlock()

            view.viewOffset += compressedLength || uncompressedLength

            timeout++
            if (timeout > 10000 && !foundEnd) {
                throw new Error("Max retry count reached")
            }
        }
    }

    fromInstance(root: Instance) {
        let bufferLength = 0

        //header
        bufferLength += 8 + 6 + 2 + 4 + 4 + 8

        //prepare for INST chunks
        const instances = root.GetDescendants()
        instances.push(root)

        let currentReferent = 0
        const instanceToReferent = new Map<Instance,number>()

        let currentClassId = 0
        const classIdMap = new Map<string,number>()
        const instanceMap = new Map<number,Instance[]>()

        for (const child of instances) {
            //give instance a referent
            instanceToReferent.set(child, currentReferent++)

            //give classname an id
            let classId = classIdMap.get(child.className)
            if (classId === undefined) {
                classId = currentClassId++
                classIdMap.set(child.className, classId)
            }

            //add instance to map, class -> instances[]
            let instanceArray = instanceMap.get(classId)
            if (!instanceArray) {
                instanceArray = []
                instanceMap.set(classId, instanceArray)
            }
            instanceArray.push(child)
        }

        //create INST chunks
        for (const className of classIdMap.keys()) {
            bufferLength += 4 + 4 + 4 + 4

            const inst = new INST()
            inst.classID = classIdMap.get(className)!
            inst.className = className
            inst.instanceCount = instanceMap.get(inst.classID)!.length
            inst.objectFormat = 0 //TODO: do this properly
            bufferLength += 4 + 4 + inst.className.length + 1 + 4

            inst.referents = []
            for (const child of instanceMap.get(inst.classID)!) {
                inst.referents.push(instanceToReferent.get(child)!)
                bufferLength += 4
            }

            this.instArray.push(inst)
            this.classIDtoINST.set(inst.classID, inst)
        }

        //prepare PROP chunks
        const propertiesForClass = new Map<number,string[]>()
        for (const child of instances) {
            const classId = classIdMap.get(child.className)!

            let properties = propertiesForClass.get(classId)
            if (!properties) {
                properties = child.getPropertyNames()
                propertiesForClass.set(classId, properties)
            } else {
                for (const property of child.getPropertyNames()) {
                    if (!properties.includes(property)) {
                        properties.push(property)
                    }
                }
            }
        }

        //create PROP chunks
        for (const classId of classIdMap.values()) {
            const properties = propertiesForClass.get(classId)
            if (properties) {
                for (const property of properties) {
                    const prop = new PROP()
                    prop.classID = classId
                    prop.propertyName = property

                    bufferLength += 4 + 4 + 4 + 4
                    bufferLength += 4 + 4 + prop.propertyName.length + 1
                    
                    const instances = instanceMap.get(classId)
                    if (instances) {
                        for (const child of instances) {
                            if (child.HasProperty(property)) {
                                prop.typeID = child.PropertyType(property)!

                                const value = child.Prop(property)
                                prop.values.push(value)

                                switch (prop.typeID) {
                                    case DataType.String:
                                        if (value instanceof ArrayBuffer) {
                                            bufferLength += value.byteLength + 4
                                        } else {
                                            bufferLength += (value as string).length + 4
                                        }
                                        break
                                    case DataType.Bool:
                                        bufferLength += 1
                                        break
                                    case DataType.Int32:
                                        bufferLength += 4
                                        break
                                    case DataType.Float32:
                                        bufferLength += 4
                                        break
                                    case DataType.Float64:
                                        bufferLength += 4
                                        break
                                    case DataType.UDim:
                                        bufferLength += 8
                                        break
                                    case DataType.UDim2:
                                        bufferLength += 4 * 4
                                        break
                                    case DataType.Ray:
                                        bufferLength += 4 * 6
                                        break
                                    case DataType.BrickColor:
                                        bufferLength += 4
                                        break
                                    case DataType.Vector2:
                                    case DataType.NumberRange:
                                        bufferLength += 4 * 2
                                        break
                                    case DataType.Color3:
                                    case DataType.Vector3:
                                        bufferLength += 4 * 3
                                        break
                                    case DataType.CFrame:
                                        bufferLength += 1 + 4 * 9 + 4 * 3
                                        break
                                    case DataType.Enum:
                                        bufferLength += 4
                                        break
                                    case DataType.Referent:
                                        bufferLength += 4
                                        break
                                    case DataType.Color3uint8:
                                        bufferLength += 4
                                        break
                                    case DataType.Int64:
                                        bufferLength += 8
                                        break
                                    case DataType.Content:
                                        if (value instanceof Content) {
                                            bufferLength += 4
                                            bufferLength += (value.uri?.length || 0) + 4
                                            bufferLength += 4
                                            bufferLength += 4
                                        }
                                        break
                                }
                            }
                        }
                    }

                    this.propArray.push(prop)
                }
            }
        }

        const buffer = new ArrayBuffer(bufferLength)

        //write data
        const view = new RBXSimpleView(buffer)

        //magic, signature, version
        view.writeUtf8String("<roblox", false)
        view.writeUint32(168689545)
        view.writeUint16(2586)
        view.writeUint16(0)

        view.writeUint32(this.instArray.length)
        view.writeUint32(this.instances.length)

        view.writeUint32(0)
        view.writeUint32(0)

        //inst chunks
        for (const inst of this.instArray) {
            view.writeUtf8String("INST", false)

            view.writeUint32(inst.classID)
            view.writeUtf8String(inst.className)
            view.writeUint8(0)

            const instances = instanceMap.get(inst.classID)!
            view.writeUint32(instances.length)
            for (const child of instances) {
                const referent = instanceToReferent.get(child)!
                view.writeUint32(referent)
            }
        }

        return buffer
    }

    /**
     * Generates if needed hierarchy and returns root instance
     * @returns Root instance
     */
    generateTree() {
        if (this.treeGenerated) {
            warn(false, "Tree already generated")
            return this.dataModel
        }

        if (!this.xmlString) {
            const referentToInstance = new Map<number,Instance>() //<referent,instance>

            //instances
            for (const inst of this.instArray) {
                for (let i = 0; i < inst.instanceCount; i++) {
                    const instance = new Instance(inst.className, true)
                    instance.classID = inst.classID
                    instance.objectFormat = inst.objectFormat

                    if (referentToInstance.get(inst.referents[i])) {
                        throw new Error(`Duplicate referent ${inst.referents[i]}`)
                    }
                    referentToInstance.set(inst.referents[i], instance)
                }
            }

            //properties
            for (const prop of this.propArray) {
                const inst = this.classIDtoINST.get(prop.classID)
                for (let i = 0; i < inst.referents.length; i++) {
                    const referent = inst.referents[i]
                    const instance = referentToInstance.get(referent)

                    if (!instance) {
                        throw new Error(`Instance with referent ${referent} is missing`)
                    }

                    const property = new Property()
                    property.name = prop.propertyName
                    property.typeID = prop.typeID
                    
                    instance.addProperty(property)
                    switch (property.typeID) {
                        case DataType.Referent:
                            {
                                const referenced = referentToInstance.get(prop.values[i] as number)
                                instance.setProperty(property.name, referenced)
                                break
                            }
                        case DataType.SharedString:
                            {
                                const str = this.sstrArr[prop.values[i] as number]
                                instance.setProperty(property.name, str)
                                break
                            }
                        default:
                            {
                                instance.setProperty(property.name, prop.values[i])
                                break
                            }
                    }

                    //if (property.typeID == DataType.BrickColor) {
                    //    console.log(instance.GetFullName())
                    //    console.log(property.name)
                    //}
                }
            }

            //hierarchy
            for (let i = 0; i < this.prnt.instanceCount; i++) {
                const childReferent = this.prnt.childReferents[i]
                const parentReferent = this.prnt.parentReferents[i]

                const child = referentToInstance.get(childReferent)
                const parent = referentToInstance.get(parentReferent)

                if (!child) {
                    warn(false, `Child with referent ${childReferent} does not exist`)
                    continue;
                }

                if (!parent && parentReferent !== -1) {
                    warn(false, `Parent with referent ${parentReferent} does not exist`)
                    continue;
                }

                if (parentReferent !== -1) {
                    child.setParent(parent)
                } else {
                    child.setParent(this.dataModel)
                }
            }

            this.treeGenerated = true
        } else {
            const xml = new DOMParser().parseFromString(this.xmlString, "text/xml")
            this.fromXML(xml)
        }

        for (const child of this.dataModel.GetDescendants()) {
            child.createWrapper()
        }

        return this.dataModel
    }
}

export function isAffectedByHumanoid(child: Instance) {
    const parent = child.parent
    if (!parent) {
        return false
    }
    if (Object.hasOwn(BodyPartNameToEnum, child.Property("Name") as string)) { //check if part is one of the parts inside an R6 rig affected by humanoids
        if (parent) {
            const humanoid = parent.FindFirstChildOfClass("Humanoid")
            if (humanoid) {
                return true
            }
        }
    }

    return false
}

export function hasSameValFloat(instance0: Instance, instance1: Instance, propertyName: string) {
    return Math.round(instance0.Prop(propertyName) as number * 1000) === Math.round(instance1.Prop(propertyName) as number * 1000)
}

export function hasSameVal(instance0: Instance, instance1: Instance, propertyName: string) {
    return instance0.Prop(propertyName) === instance1.Prop(propertyName)
}

export function isSameColor(color0: Color3, color1: Color3) {
    return Math.round(color0.R * 1000) === Math.round(color1.R * 1000) && Math.round(color0.G * 1000) === Math.round(color1.G * 1000) && Math.round(color0.B * 1000) === Math.round(color1.B * 1000)
}

export function isSameVector3(vec0: Vector3, vec1: Vector3) {
    return Math.round(vec0.X * 1000) === Math.round(vec1.X * 1000) && Math.round(vec0.Y * 1000) === Math.round(vec1.Y * 1000) && Math.round(vec0.Z * 1000) === Math.round(vec1.Z * 1000)
}

export function isSameFloat(num0: number, num1: number) {
    return Math.round(num0 * 100) === Math.round(num1 * 100)
}