import * as THREE from 'three'
import { CFrame, Instance, isAffectedByHumanoid, Vector3 } from "../../rblx/rbx";
import { MaterialDesc } from "./../subDescs/materialDesc";
import { MeshDesc } from "./../subDescs/meshDesc";
import { MeshType } from '../../rblx/constant';
import { SkeletonDesc } from './../subDescs/skeletonDesc';
import { traverseRigCFrame } from '../../rblx/scale';
import { API } from '../../api';
import { RenderDesc, setTHREEObjectCF } from './../renderDesc';
import { FLAGS } from '../../misc/flags';
import { warn } from '../../misc/logger';
import { specialClamp } from '../../misc/misc';

export const PartTypes = ["Part", "WedgePart"]
export const MeshPartTypes = ["MeshPart"]

/**
 * Used to describe how Parts, MeshParts and Decals should be rendered
 */
export class ObjectDesc extends RenderDesc {
    static classTypes: string[] = ["Part", "WedgePart", "MeshPart", "Decal"]

    cframe: CFrame = new CFrame()
    size: Vector3 = new Vector3(1,1,1)
    
    meshDesc: MeshDesc = new MeshDesc()
    materialDesc: MaterialDesc = new MaterialDesc()
    skeletonDesc?: SkeletonDesc

    //skinning
    isBodyPart: boolean = false
    isSkinned: boolean = false //based on compiled mesh

    originalScale: THREE.Vector3 = new THREE.Vector3(1,1,1) //based on compiled mesh

    isSame(other: ObjectDesc) {
        return this.cframe.isSame(other.cframe) &&
                this.meshDesc.isSame(other.meshDesc) &&
                this.materialDesc.isSame(other.materialDesc) &&
                this.isBodyPart === other.isBodyPart &&
                this.size.isSame(other.size) &&
                this.skeletonDesc === other.skeletonDesc //this looks like a mistake BUT its actually intentional
    }

    needsRegeneration(newDesc: ObjectDesc) {
        //layered clothing cooldown
        if (!this.renderScene.forceAccurateNeedsRegeneration) {
            if (this.meshDesc.layerDesc && (Date.now() / 1000) - this.meshDesc.compilationTimestamp < FLAGS.LAYERED_CLOTHING_COOLDOWN) {
                return false
            }
        }

        return !this.meshDesc.isSame(newDesc.meshDesc) || this.materialDesc.needsRegeneration(newDesc.materialDesc)
    }

    virtualFromRenderDesc(other: ObjectDesc) {
        //everything that doesnt require compilation should be here
        this.cframe = other.cframe
        this.size = other.size
        this.isBodyPart = other.isBodyPart

        this.materialDesc.fromMaterialDesc(other.materialDesc)
    }

    fromInstance(child: Instance) {
        this.instance = child

        let part: Instance | undefined = child
        if (!PartTypes.includes(part.className) && !MeshPartTypes.includes(part.className)) {
            if (part.parent && (PartTypes.includes(part.parent.className) || MeshPartTypes.includes(part.parent.className))) {
                part = part.parent
            } else {
                part = undefined
            }
        }

        //cframe
        if (part && part.HasProperty("CFrame")) {
            this.cframe = part.Prop("CFrame") as CFrame

            if (part.FindFirstChildOfClass("WrapLayer")) {
                if (part.parent && part.parent.parent) {
                    const hrp = part.parent.parent.FindFirstChild("HumanoidRootPart")
                    if (hrp) {
                        this.cframe = hrp.Prop("CFrame") as CFrame
                    }
                }
            }
        }

        //skinning
        if (part && isAffectedByHumanoid(part)) {
            if (part.Prop("Name") !== "Head") {
                this.isBodyPart = true
            }
        }

        //mesh size
        if (part) {
            switch (part.className) {
                case "WedgePart":
                case "Part": {
                    if (!isAffectedByHumanoid(part)) this.size = part.PropOrDefault("Size", this.size) as Vector3

                    const specialMesh = part.FindFirstChildOfClass("SpecialMesh")
                    if (specialMesh) {
                        this.size = specialMesh.Property("Scale") as Vector3
                        if (specialMesh.HasProperty("Offset")) {
                            this.cframe = this.cframe.multiply(new CFrame(...(specialMesh.Prop("Offset") as Vector3).toVec3()))
                        }

                        switch (specialMesh.Property("MeshType")) {
                            case MeshType.Head: {
                                this.size = this.size.multiply(new Vector3(0.8, 0.8, 0.8))
                                break
                            }
                            default: {
                                break
                            }
                        }
                    }
        
                    break
                }
                case "MeshPart": {
                    this.size = part.Property("Size") as Vector3

                    //wrap layer
                    const wrapLayer = part.FindFirstChildOfClass("WrapLayer")

                    let model = undefined
                    if (part.parent?.className === "Model") {
                        model = part.parent
                    }
                    if (part.parent?.parent?.className === "Model") {
                        model = part.parent.parent
                    }

                    if (wrapLayer && model) {
                        this.size = new Vector3(1,1,1)
                    }

                    break
                }
            }
        }

        this.meshDesc.fromInstance(child)
        this.materialDesc.fromInstance(child)
    }

    async compileResults(_renderer: THREE.WebGLRenderer, scene: THREE.Scene): Promise<THREE.Object3D[] | Response | undefined> {
        const loadingLabel = this.instance ? this.instance.GetFullName() : "unknown"
        API.Misc.startCurrentlyLoadingAssets(loadingLabel)

        try {
            this.results = undefined
            this.skeletonDesc = undefined

            //compile dependencies
            const promises: [Promise<THREE.Mesh | Response | undefined>, Promise<THREE.MeshStandardMaterial | THREE.MeshPhongMaterial>] = [
                this.meshDesc.compileMesh(),
                this.materialDesc.compileMaterial(this.meshDesc)
            ]

            const [threeMesh, threeMaterial]: [THREE.Mesh | Response | undefined, THREE.MeshStandardMaterial | THREE.MeshPhongMaterial] = await Promise.all(promises)
            if (!(threeMesh instanceof THREE.Mesh)) {
                warn(true, "Failed to get mesh for objectDesc", this.instance ? this.instance.GetFullName() : "unknown")
                return threeMesh
            }

            //material
            if (threeMesh instanceof THREE.SkinnedMesh) {
                (threeMaterial as unknown as {[skinning: string]: boolean}).skinning = true
                this.isSkinned = true
            }
            threeMesh.material = threeMaterial
            threeMesh.receiveShadow = true
            threeMaterial.needsUpdate = true
            //threeMesh.visible = threeMaterial.visible

            this.results = [threeMesh]
            
            //scale
            this.originalScale = threeMesh.scale.clone()
            
            if (!this.meshDesc.scaleIsRelative) {
                threeMesh.scale.set(this.size.X, this.size.Y, this.size.Z)
            } else {
                const oldSize = this.originalScale
                const [sX, sY, sZ] = [
                    specialClamp(this.size.X / oldSize.x, 0.00001, 1000000), 
                    specialClamp(this.size.Y / oldSize.y, 0.00001, 1000000), 
                    specialClamp(this.size.Z / oldSize.z, 0.00001, 1000000)]

                threeMesh.scale.set(sX, sY, sZ)
            }

            //skeleton
            if (SkeletonDesc.descNeedsSkeleton(this.meshDesc)) {
                this.skeletonDesc = new SkeletonDesc(this, this.meshDesc, scene)
            } else {
                this.meshDesc.fileMesh = undefined
            }
        } finally {
            API.Misc.stopCurrentlyLoadingAssets(loadingLabel)
        }

        return this.results
    }

    getScale() {
        if (!this.results) {
            return new Vector3(1,1,1)
        }

        if (!this.meshDesc.scaleIsRelative) {
            return new Vector3(this.size.X, this.size.Y, this.size.Z)
        } else {
            const oldSize = this.originalScale
            const [sX, sY, sZ] = [
                    specialClamp(this.size.X / oldSize.x, 0.00001, 1000000), 
                    specialClamp(this.size.Y / oldSize.y, 0.00001, 1000000), 
                    specialClamp(this.size.Z / oldSize.z, 0.00001, 1000000)]

            return new Vector3(sX, sY, sZ)
        }
    }

    updateResults() {
        if (this.results) {
            let resultCF = this.cframe

            if (this.isSkinned && this.instance) {
                let partToUse = this.instance
                if (partToUse.className === "Decal" && partToUse.parent) {
                    partToUse = partToUse.parent
                }

                const hrp = partToUse.parent?.FindFirstChild("HumanoidRootPart")
                if (hrp) {
                    resultCF = (hrp.Prop("CFrame") as CFrame).multiply(traverseRigCFrame(partToUse))
                }
            }

            //apply size
            for (const result of this.results) {
                result.scale.set(...this.getScale().toVec3())
                
                setTHREEObjectCF(result, resultCF)
                result.updateMatrix()
                result.updateMatrixWorld(true)
                
                if (this.skeletonDesc && this.instance) {
                    if (result instanceof THREE.SkinnedMesh) {
                        result.bindMatrix.copy(result.matrixWorld.clone())
                        result.bindMatrixInverse.copy(result.matrixWorld.clone().invert())
                    }
                    if (this.instance.className !== "Decal") {
                        this.skeletonDesc.update(this.instance)
                    } else if (this.instance.parent) {
                        this.skeletonDesc.update(this.instance.parent)
                    }
                }
            }
        }

        if (this.materialDesc.result) {
            this.materialDesc.updateResult()

            if (this.results) {
                for (const result of this.results) {
                    result.visible = this.materialDesc.visible
                }
            }
        }
    }

    static shouldRenderInstance(instance: Instance) {
        //check that this decal isnt baked and should get its own ObjectDesc
        const isDecal = instance.className === "Decal"
        const isBakedDecal = isDecal && !instance.FindFirstChildOfClass("WrapTextureTransfer")
        let isFirstDecal = true
        if (isDecal && instance.parent) {
            const children = instance.parent.GetChildren()
            for (const child of children) {
                if (child.className === "Decal" && child.FindFirstChildOfClass("WrapTextureTransfer") && child.id < instance.id) {
                    isFirstDecal = false
                }
            }
        }

        return !isBakedDecal && (!isDecal || isFirstDecal)
    }

    //Used to dispose OLD stuff
    dispose(renderer: THREE.WebGLRenderer) {
        if (this.results) {
            for (const result of this.results) {
                result.removeFromParent()
            }
        }

        if (this.meshDesc) this.meshDesc.dispose(renderer)
        if (this.materialDesc) this.materialDesc.dispose()
        if (this.skeletonDesc) this.skeletonDesc.dispose()
    }
}