import { AllAvatarModelOutfitUpdateTypes, type AvatarInventory_Result, type AvatarModel_Result, type BundleDetails_Result, type GetBackground_Result, type GetInfoForId_Result, type GetSubscription_Result, type GetTopics_Payload, type GetTopics_Result, type GetUserOutfits_Result, type ItemDetail_Result, type ItemDetails_Result, type LatestVersions_Result, type Look_Result, type MarketplaceWidgets_Result, type NavigationMenuItems, type OutfitModel_Result, type Search_Payload, type Search_Result, type ThumbnailCustomizations_Result, type ThumbnailsCustomization_Payload, type UserLooks_Result, type UserOmniSearch_Result } from "./api-constant"
import { OutfitOrigin } from "./avatar/constant"
import { LocalOutfit, type LocalOutfitJson } from "./avatar/local-outfit"
import { BodyColors, Outfit } from "./avatar/outfit"
import { ItemSort } from "./avatar/sorts"
import { generateUUIDv4 } from "./misc/misc"
import { FileMesh } from "./mesh/mesh"
import { Event, RBX } from "./rblx/rbx"
import { RoAvatarData, type RoAvatarBrowser } from "./rblx/roavatar-data-parser"
import { FLAGS } from "./misc/flags"
import { log, warn } from "./misc/logger"
import { OutfitModel } from "./avatar/outfitModel"

declare const browser: typeof chrome;

/** @category API */
export class Authentication {
    TOKEN?: string
    SessionUUID?: string

    info?: {id: number, name: string, displayName: string}

    lastRefreshed = new Date().getTime()

    async getUserInfo() {
        if (this.info) {
            return this.info
        }

        const info = await API.Users.GetUserInfo()
        this.info = info
        return info
    }

    async getToken() {
        throw new Error("Deprecated member function auth.getToken() was called!")
    }

    getCachedToken() {
        return this.TOKEN
    }

    getSessionUUID() {
        if (!this.SessionUUID) {
            this.SessionUUID = generateUUIDv4()
        }

        return this.SessionUUID
    }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function RBLXPost(url: string, auth: Authentication | undefined, body: any, attempt = 0, method = "POST"): Promise<Response> {
    if (url.match(/https?:\/\/[a-z]+.roblox.com/)) {
        url = url.replace("roblox.com", FLAGS.API_DOMAIN)
    }

    if ((typeof body) !== "string") {
        body = JSON.stringify(body)
    }

    let xCsrfToken = ""

    if (auth) {
        xCsrfToken = auth.getCachedToken() || ""

        if (!xCsrfToken) {
            xCsrfToken = ""
        }
    }

    const response = await new Promise<Response>((resolve) => {
        const fetchHeaders = new Headers({
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": xCsrfToken,
        })

        try {
            (FLAGS.FETCH_FUNC || fetch)(FLAGS.API_REQUEST_PREFIX + url, {
                method: method,
                credentials: FLAGS.INCLUDE_REQUEST_CREDENTIALS_OVERRIDE,
                headers: fetchHeaders,
                body: body
            }).then(response => {
                if (!response.ok) {
                    if (response.status === 403 && attempt < 1) { //refresh token
                        const responseToken = response.headers.get("x-csrf-token")
                        if (responseToken && auth) {
                            auth.TOKEN = responseToken
                        }
                        resolve(RBLXPost(url, auth, body, attempt + 1, method))
                    } else {
                        resolve(response)
                    }
                } else {
                    resolve(response)
                }
            }).catch((error) => {
                warn(true, error)
                resolve(new Response(JSON.stringify({"error": error}), {status: 500}))
            })
        } catch (error) {
            warn(true, error)
            resolve(new Response(JSON.stringify({"error": error}), {status: 500}))
        }
    })

    if (FLAGS.API_REQUEST_RETRY && !response.ok && attempt === 0) {
        return RBLXPost(url, auth, body, attempt + 1, method)
    } else {
        return response
    }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function RBLXGet(url: string, headers?: any, includeCredentials: boolean = true, attempt: number = 0): Promise<Response> {
    if (url.match(/https?:\/\/[a-z]+.roblox.com/)) {
        url = url.replace("roblox.com", FLAGS.API_DOMAIN)
    }

    const response = await new Promise<Response>((resolve) => {
        let newHeaders: HeadersInit = {
            "Content-Type": "application/json",
        }

        if (headers) {
            newHeaders = {...newHeaders, ...headers}
        }

        if (url.includes("rbxcdn.com")) {
            includeCredentials = false
        }

        const fetchHeaders = new Headers(newHeaders)

        try {
            (FLAGS.FETCH_FUNC || fetch)(FLAGS.API_REQUEST_PREFIX + url, {
                credentials: includeCredentials ? FLAGS.INCLUDE_REQUEST_CREDENTIALS_OVERRIDE: undefined,
                headers: fetchHeaders,
                priority: FLAGS.ASSET_REQUEST_PRIORITY,
            }).then(response => {
                resolve(response)
            }).catch((error) => {
                warn(true, error)
                resolve(new Response(JSON.stringify({"error": error}), {status: 500}))
            })
        } catch (error) {
            warn(true, error)
            resolve(new Response(JSON.stringify({"error": error}), {status: 500}))
        }
    })

    if (FLAGS.API_REQUEST_RETRY && !response.ok && attempt === 0) {
        return RBLXGet(url, headers, includeCredentials, attempt + 1)
    } else {
        return response
    }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function RBLXDelete(url: string, auth: Authentication, body: any, attempt = 0): Promise<Response> {
    return RBLXPost(url, auth, body, attempt, "DELETE")
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function RBLXPatch(url: string, auth: Authentication, body: any, attempt = 0): Promise<Response> {
    return RBLXPost(url, auth, body, attempt, "PATCH")
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function getAssetBufferInternal(url: string, headers: any, extraStr?: string) {
    const loadingLabel = `getAssetBufferInternal-${url}-${extraStr}`
    API.Misc.startCurrentlyLoadingAssets(loadingLabel)

    const fetchStr = await API.Misc.assetURLToCDNURL(url, headers, extraStr)
    if (fetchStr instanceof Response) {
        API.Misc.stopCurrentlyLoadingAssets(loadingLabel)
        return fetchStr
    }

    const response = await RBLXGet(fetchStr, undefined, false)
    API.Misc.stopCurrentlyLoadingAssets(loadingLabel)
    if (response.status === 200) {
        const data = await response.arrayBuffer()
        /*if (FLAGS.ENABLE_API_CACHE) {
            CACHE.AssetBuffer.set(cacheStr, data)
        }*/
        return data
    } else {
        warn(true, "Failed to get assetBufer for", fetchStr, "status:", response.status)
        return response
    }
}

//let isCurrentlyLoading = false
const currentlyLoadingAssets: string[] = []

export type CurrentlyLoadingUpdateType = "start" | "finish"

function _updateCurrentlyLoadingAssets(type: CurrentlyLoadingUpdateType, label: string) {
    const newCurrentlyLoading = currentlyLoadingAssets.length > 0
    //if (isCurrentlyLoading !== newCurrentlyLoading) {
        API.Events.OnLoadingAssets.Fire(newCurrentlyLoading, type, label)
    //}
    //isCurrentlyLoading = newCurrentlyLoading
}

export type UserInfo = {id: number, name: string, displayName: string}

/**
 * @category API
 */
export class Cache<K, V> {
    map: Map<K,V> = new Map<K,V>()
    lastAccess: Map<K,number> = new Map()

    maxEntries: number
    minDeleteLifetime: number = 5

    onDelete?: (key: K) => void

    constructor(maxEntries: number = 250) {
        this.maxEntries = maxEntries
    }

    get(key: K): V | undefined {
        if (this.map.has(key)) {
            this.lastAccess.set(key, Date.now())
        }

        return this.map.get(key)
    }

    set(key: K, value: V): Cache<K,V> {
        this.map.set(key, value)
        this.lastAccess.set(key, Date.now())

        this.deleteUntil()

        return this
    }

    has(key: K): boolean {
        return this.map.has(key)
    }

    delete(key: K): boolean {
        if (this.onDelete) this.onDelete(key)

        const toReturn = this.map.delete(key)
        this.lastAccess.delete(key)

        return toReturn
    }

    deleteUntil() {
        while (this.map.size > this.maxEntries) {
            if (!this.deleteOne()) break
        }
    }

    deleteOne(): boolean {
        //delete from cache when it reaches limit
        if (this.map.size > this.maxEntries) {
            const toDelete = [...this.lastAccess.entries()].reduce((min, current) => {
                return current[1] < min[1] ? current : min
            })

            if (Date.now() - toDelete[1] >= this.minDeleteLifetime * 1000) {
                this.delete(toDelete[0])
                return true
            }
        }

        return false
    }
}

/**
 * @category API
 */
export const CACHE = {
    "AssetBuffer": new Cache<string,Promise<Response | ArrayBuffer>>(100),
    "RBX": new Cache<string,RBX>(100),
    "Mesh": new Cache<string,FileMesh>(100),
    "Image": new Cache<string,Promise<HTMLImageElement | undefined> | HTMLImageElement | undefined>(100),
    "Thumbnails": new Cache<string,string | undefined>(1000),
    "ItemOwned": new Cache<string,[boolean,number]>(1000),
    "IsLayered": new Cache<number,boolean>(1000),
    "AvatarInventoryItem": new Cache<string,AvatarInventory_Result>(1000),
    "ItemDetails": new Cache<string,ItemDetail_Result>(10000),
    "UserInfo": undefined,
}

/**
 * Sets the APICACHE to a preset value
 * 
 * @param preset
 * 
 * @category API
 */
export function setCacheFootprintPreset(preset: "none" | "low" | "normal" | "high") {
    switch (preset) {
        case "none":
            CACHE.AssetBuffer.maxEntries = 0
            CACHE.RBX.maxEntries = 0
            CACHE.Mesh.maxEntries = 0
            CACHE.Image.maxEntries = 0
            CACHE.Thumbnails.maxEntries = 0
            CACHE.ItemOwned.maxEntries = 0
            CACHE.IsLayered.maxEntries = 0
            CACHE.AvatarInventoryItem.maxEntries = 0
            CACHE.ItemDetails.maxEntries = 0
            break
        case "low":
            CACHE.AssetBuffer.maxEntries = 10
            CACHE.RBX.maxEntries = 10
            CACHE.Mesh.maxEntries = 10
            CACHE.Image.maxEntries = 10
            CACHE.Thumbnails.maxEntries = 500
            CACHE.ItemOwned.maxEntries = 500
            CACHE.IsLayered.maxEntries = 100
            CACHE.AvatarInventoryItem.maxEntries = 500
            CACHE.ItemDetails.maxEntries = 5000
            break
        case "normal":
            CACHE.AssetBuffer.maxEntries = 100
            CACHE.RBX.maxEntries = 100
            CACHE.Mesh.maxEntries = 100
            CACHE.Image.maxEntries = 100
            CACHE.Thumbnails.maxEntries = 1000
            CACHE.ItemOwned.maxEntries = 1000
            CACHE.IsLayered.maxEntries = 1000
            CACHE.AvatarInventoryItem.maxEntries = 1000
            CACHE.ItemDetails.maxEntries = 10000
            break
        case "high":
            CACHE.AssetBuffer.maxEntries = 250
            CACHE.RBX.maxEntries = 250
            CACHE.Mesh.maxEntries = 250
            CACHE.Image.maxEntries = 250
            CACHE.Thumbnails.maxEntries = 1000
            CACHE.ItemOwned.maxEntries = 1000
            CACHE.IsLayered.maxEntries = 1000
            CACHE.AvatarInventoryItem.maxEntries = 1000
            CACHE.ItemDetails.maxEntries = 10000
            break
    }
}

export const ContentMap = new Map<string,string>()

export function createContentMap() {
    ContentMap.set("rbxasset://fonts/BaseballCap.mesh",	"12220916")
    ContentMap.set("rbxasset://fonts/clonewand.mesh", "12221344")
    ContentMap.set("rbxasset://fonts/fusedgirl.mesh", "12221423")
    ContentMap.set("rbxasset://fonts/girlhair.mesh", "12221431")
    ContentMap.set("rbxasset://fonts/hammer.mesh", "12221451")
    ContentMap.set("rbxasset://fonts/NinjaMask.mesh", "12221524")
    ContentMap.set("rbxasset://fonts/paintballgun.mesh", "11900867")
    ContentMap.set("rbxasset://fonts/pawn.mesh", "12221585")
    ContentMap.set("rbxasset://fonts/PirateHat.mesh", "12221595")
    ContentMap.set("rbxasset://fonts/PoliceCap.mesh", "12221603")
    ContentMap.set("rbxasset://fonts/rocketlauncher.mesh", "12221651")
    ContentMap.set("rbxasset://fonts/slingshot.mesh", "12221682")
    ContentMap.set("rbxasset://fonts/sombrero.mesh", "12221705")
    ContentMap.set("rbxasset://fonts/sword.mesh", "12221720")
    ContentMap.set("rbxasset://fonts/timebomb.mesh", "12221733")
    ContentMap.set("rbxasset://fonts/tophat.mesh", "12221750")
    ContentMap.set("rbxasset://fonts/tree.mesh", "12221787")
    ContentMap.set("rbxasset://fonts/trowel.mesh", "12221793")
    ContentMap.set("rbxasset://fonts/VikingHelmet.mesh", "12221815")

    if (FLAGS.ONLINE_ASSETS) {
        //particles
        ContentMap.set("rbxasset://textures/particles/SquareParticle.png", "rbxassetid://81536466622192")
        ContentMap.set("rbxasset://textures/particles/sparkles_main.png", "rbxassetid://87394320952325")
        ContentMap.set("rbxasset://textures/particles/sparkles_color.png", "rbxassetid://133057519435872")
        ContentMap.set("rbxasset://textures/particles/smoke_main.png", "rbxassetid://138162637433023")
        ContentMap.set("rbxasset://textures/particles/smoke_color.png", "rbxassetid://125845160650254")
        ContentMap.set("rbxasset://textures/particles/legacy_fire_alpha_color.png", "rbxassetid://118480963109188")
        ContentMap.set("rbxasset://textures/particles/forcefield_vortex_main.png", "rbxassetid://90748587720186")
        ContentMap.set("rbxasset://textures/particles/forcefield_vortex_color.png", "rbxassetid://114134905691033")
        ContentMap.set("rbxasset://textures/particles/forcefield_glow_main.png", "rbxassetid://118476782259878")
        ContentMap.set("rbxasset://textures/particles/forcefield_glow_color.png", "rbxassetid://136830612119909")
        ContentMap.set("rbxasset://textures/particles/forcefield_glow_alpha.png", "rbxassetid://127202098262235")
        ContentMap.set("rbxasset://textures/particles/forcefield_alpha.png", "rbxassetid://114076943026381")
        ContentMap.set("rbxasset://textures/particles/fire_sparks_main.png", "rbxassetid://104223768023861")
        ContentMap.set("rbxasset://textures/particles/fire_sparks_color.png", "rbxassetid://140709297018478")
        ContentMap.set("rbxasset://textures/particles/fire_main.png", "rbxassetid://95195318391696")
        ContentMap.set("rbxasset://textures/particles/fire_color.png", "rbxassetid://71855354689630")
        ContentMap.set("rbxasset://textures/particles/fire_alpha.png", "rbxassetid://137123937216738")
        ContentMap.set("rbxasset://textures/particles/explosion01_smoke_main.png", "rbxassetid://93992972651499")
        ContentMap.set("rbxasset://textures/particles/explosion01_smoke_color_new.png", "rbxassetid://86144670293531")
        ContentMap.set("rbxasset://textures/particles/explosion01_smoke_alpha.png", "rbxassetid://138742967158809")
        ContentMap.set("rbxasset://textures/particles/explosion01_shockwave_main.png", "rbxassetid://116101962979677")
        ContentMap.set("rbxasset://textures/particles/explosion01_implosion_main.png", "rbxassetid://86764380638770")
        ContentMap.set("rbxasset://textures/particles/explosion01_implosion_color.png", "rbxassetid://127669378194473")
        ContentMap.set("rbxasset://textures/particles/explosion01_core_main.png", "rbxassetid://94075508535469")
        ContentMap.set("rbxasset://textures/particles/explosion01_core_alpha.png", "rbxassetid://99241903368204")
        ContentMap.set("rbxasset://textures/particles/explosion_color.png", "rbxassetid://93670753826336")
        ContentMap.set("rbxasset://textures/particles/explosion_alpha.png", "rbxassetid://115975840525503")
        ContentMap.set("rbxasset://textures/particles/common_alpha.png", "rbxassetid://76897028114182")

        //textures
        ContentMap.set("rbxasset://textures/face.png", "rbxassetid://126076136486265")

        //meshes
        ContentMap.set("rbxasset://avatar/meshes/torso.mesh", "85617550700848")
        ContentMap.set("rbxasset://avatar/meshes/rightleg.mesh", "72388106457735")
        ContentMap.set("rbxasset://avatar/meshes/rightarm.mesh", "111146997566389")
        ContentMap.set("rbxasset://avatar/meshes/leftleg.mesh", "90013209978879")
        ContentMap.set("rbxasset://avatar/meshes/leftarm.mesh", "107015122138989")
        ContentMap.set("rbxasset://avatar/heads/headP.mesh", "92893933522111")
        ContentMap.set("rbxasset://avatar/heads/headO.mesh", "77541016415293")
        ContentMap.set("rbxasset://avatar/heads/headN.mesh", "135830315772083")
        ContentMap.set("rbxasset://avatar/heads/headM.mesh", "72296270663395")
        ContentMap.set("rbxasset://avatar/heads/headL.mesh", "118173713712494")
        ContentMap.set("rbxasset://avatar/heads/headK.mesh", "87988019718389")
        ContentMap.set("rbxasset://avatar/heads/headJ.mesh", "87602015805248")
        ContentMap.set("rbxasset://avatar/heads/headI.mesh", "105758863945258")
        ContentMap.set("rbxasset://avatar/heads/headH.mesh", "82654813279081")
        ContentMap.set("rbxasset://avatar/heads/headG.mesh", "78217037620613")
        ContentMap.set("rbxasset://avatar/heads/headF.mesh", "81353062523004")
        ContentMap.set("rbxasset://avatar/heads/headE.mesh", "113298530836166")
        ContentMap.set("rbxasset://avatar/heads/headD.mesh", "84378174703962")
        ContentMap.set("rbxasset://avatar/heads/headC.mesh", "114955209749256")
        ContentMap.set("rbxasset://avatar/heads/headB.mesh", "86540893905615")
        ContentMap.set("rbxasset://avatar/heads/headA.mesh", "77314442147190")
        ContentMap.set("rbxasset://avatar/heads/head.mesh", "84927473172716")
        ContentMap.set("rbxasset://avatar/compositing/R15CompositTorsoBase.mesh", "128898737887110")
        ContentMap.set("rbxasset://avatar/compositing/R15CompositRightArmBase.mesh", "130403245999873")
        ContentMap.set("rbxasset://avatar/compositing/R15CompositLeftArmBase.mesh", "122438986243654")
        ContentMap.set("rbxasset://avatar/compositing/CompositTShirt.mesh", "73352601509228")
        ContentMap.set("rbxasset://avatar/compositing/CompositTorsoBase.mesh", "110815013780474")
        ContentMap.set("rbxasset://avatar/compositing/CompositShirtTemplate.mesh", "99918409598660")
        ContentMap.set("rbxasset://avatar/compositing/CompositRightLegBase.mesh", "107252470435894")
        ContentMap.set("rbxasset://avatar/compositing/CompositRightArmBase.mesh", "86285571969113")
        ContentMap.set("rbxasset://avatar/compositing/CompositQuad.mesh", "86988649991001")
        ContentMap.set("rbxasset://avatar/compositing/CompositPantsTemplate.mesh", "108749124518615")
        ContentMap.set("rbxasset://avatar/compositing/CompositLeftLegBase.mesh", "126843307192697")
        ContentMap.set("rbxasset://avatar/compositing/CompositLeftArmBase.mesh", "124757651657333")
        ContentMap.set("rbxasset://avatar/compositing/CompositFullAtlasOverlayTexture.mesh", "99832238544592")
        ContentMap.set("rbxasset://avatar/compositing/CompositFullAtlasBaseTexture.mesh", "82745085603378")
        ContentMap.set("rbxasset://avatar/compositing/CompositExtraSlot4.mesh", "90442767118712")
        ContentMap.set("rbxasset://avatar/compositing/CompositExtraSlot3.mesh", "114465125672717")
        ContentMap.set("rbxasset://avatar/compositing/CompositExtraSlot2.mesh", "111697299800137")
        ContentMap.set("rbxasset://avatar/compositing/CompositExtraSlot1.mesh", "92101687933174")
        ContentMap.set("rbxasset://avatar/compositing/CompositExtraSlot0.mesh", "115275146529093")
    }

    //rigs
    if (FLAGS.ONLINE_ASSETS) {
        //rbxm
        ContentMap.set("roavatar://RigR6.rbxm", "134202675113006")
        ContentMap.set("roavatar://RigR15.rbxm", "117612227055721")
    } else {
        //rbxm
        ContentMap.set("roavatar://RigR6.rbxm", FLAGS.RIG_PATH + "RigR6.rbxm")
        ContentMap.set("roavatar://RigR15.rbxm", FLAGS.RIG_PATH + "RigR15.rbxm")
    }

    //from roavatar, always online
    ContentMap.set("roavatar://AvatarEditorScene.rbxm", "74148511291027")
    ContentMap.set("roavatar://AvatarSceneNew.rbxm", "130507237273896")
    ContentMap.set("roavatar://AvatarCyclorama.rbxm", "79116945688799")
}

let CachedRoAvatarData: undefined | RoAvatarData = undefined

const thumbnailTypesWithBackground = ["Outfit", "Avatar", "AvatarHeadshot"]
type ThumbnailInfo = {
    auth: Authentication,
    type: string,
    id: number | string,
    size: string,
    resolves: ((url: string | undefined) => void)[],
    attempt: number,
    lastTryTimestamp: number,
    headShape?: string,
    includeBackground?: boolean,
}
let ThumbnailsToBatch: ThumbnailInfo[] = []

/**
 * Contains all API methods
 * @category API
 */
export const API = {
    "Misc": {
        "startCurrentlyLoadingAssets": function (label: string) {
            currentlyLoadingAssets.push(label)
            _updateCurrentlyLoadingAssets("start", label)
        },
        "stopCurrentlyLoadingAssets": function(label: string) {
            const labelIndex = currentlyLoadingAssets.indexOf(label)
            if (labelIndex > -1) {
                currentlyLoadingAssets.splice(labelIndex, 1)
                _updateCurrentlyLoadingAssets("finish", label)
            } else {
                throw new Error(`Invalid loading label: ${label}`)
            }
        },
        "idFromStr": function(str: string) {
            const numStrs = str.match(/\d+(\.\d+)?/g) || []
            return numStrs.length > 0 ? Number(numStrs[numStrs.length - 1]) : NaN
        },
        "parseAssetString": function(str: string) {
            let url = str

            const contentUrl = ContentMap.get(str)
            if (contentUrl) {
                log(false, `ContentMap: ${str} -> ${contentUrl}`)
                str = contentUrl
                url = str
            }

            //get fetch str/url
            if (!isNaN(Number(str))) {
                url = `https://assetdelivery.roblox.com/v1/asset?id=${str}`
            } else if (str.startsWith("rbxassetid://")) {
                url = `https://assetdelivery.roblox.com/v1/asset?id=${str.slice(13)}`
            } else if (str.startsWith("rbxasset://")) {
                str = str.replaceAll("\\","/")
                url = FLAGS.ASSETS_PATH + str.slice(11)
            } else if (str.includes("roblox.com/asset")) { //i am tired of the 1 million variants of https://www.roblox.com/asset/?id=
                url = `https://assetdelivery.roblox.com/v1/asset?id=${API.Misc.idFromStr(str)}`
            } else if (str.startsWith("https://assetdelivery.roblox.com/v1/asset/?id=")) {
                url = `https://assetdelivery.roblox.com/v1/asset?id=${str.slice(46)}`
            } else if (str.includes("assetdelivery.roblox.com")) {
                url = `https://assetdelivery.roblox.com/v1/asset?id=${API.Misc.idFromStr(str)}`
            } else if (str.startsWith(".")) { //local file
                url = str
            } else {
                warn(false, `Failed to parse path of ${str}, leaving as is`)
            }

            //use v2 instead if enabled
            if (FLAGS.ASSETDELIVERY_V2) {
                if (url.includes("/v1/")) {
                    url = url.replace("/v1/","/v2/")
                }
            }

            return url
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        "getCDNURLFromAssetDelivery": async function(url: string, headers?: any): Promise<string | Response> {
            if (!FLAGS.ASSETDELIVERY_V2 || !url.includes("assetdelivery.roblox.com/v2/")) {
                return url
            } else {
                const response = await RBLXGet(url, headers)
                if (response.status !== 200) {
                    return response
                }

                const data = await response.json()

                return data.locations[0].location
            }
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        "assetURLToCDNURL": async function(url: string | number | bigint, headers?: any, extraStr?: string): Promise<string | Response> {
            url = String(url)
            if (url.includes("rbxcdn.com")) return extraStr ? url + extraStr : url

            let fetchStr = API.Misc.parseAssetString(url) || url
            if (extraStr) {
                fetchStr += extraStr
            }
            const cdnURL = await API.Misc.getCDNURLFromAssetDelivery(fetchStr, headers)
            return cdnURL
        },
        "getCurrentlyLoading": function(): boolean {
            return currentlyLoadingAssets.length > 0
        },
        "getCurrentlyLoadingLabels": function(): string[] {
            return currentlyLoadingAssets
        }
    },
    "Events": {
        "OnLoadingAssets": new Event()
    },
    "Generic": {
        LoadImage: async function(url: string): Promise<HTMLImageElement | undefined> {
            return new Promise((resolve) => {
                const cacheURL = API.Misc.parseAssetString(url) || url

                const cachedImage = CACHE.Image.get(cacheURL)

                if (cachedImage) {
                    resolve(cachedImage)
                } else {
                    CACHE.Image.set(cacheURL, new Promise((cacheResolve) => {
                        API.Misc.assetURLToCDNURL(url).then((fetchStr) => {
                            if (fetchStr instanceof Response) {
                                resolve(undefined)
                                cacheResolve(undefined)
                                return
                            }
                            const image = new Image()
                            image.onload = () => {
                                cacheResolve(image)
                                resolve(image)
                                CACHE.Image.set(cacheURL, image)
                            }
                            image.onerror = () => {
                                cacheResolve(undefined)
                                resolve(undefined)
                                CACHE.Image.set(cacheURL, undefined)
                            }
                            image.crossOrigin = "anonymous"
                            if (FLAGS.IMAGE_FUNC) {
                                FLAGS.IMAGE_FUNC(fetchStr).then((str) => {
                                    image.src = str
                                })
                            } else {
                                image.src = fetchStr
                            }
                        })
                    }))
                }
            })
        },
        GetManifestVersion: function(): string {
            return (chrome || browser).runtime.getManifest().version
        },
        IsDevMode: function(): boolean {
            return !("update_url" in (chrome || browser).runtime.getManifest())
        },
        GetBrowser: function(): RoAvatarBrowser {
            if (API.Generic.IsDevMode()) {
                return "Dev"
            }

            if (navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                return "Firefox"
            }

            if (navigator.userAgent.indexOf("Edg") > -1) {
                return "Edge"
            }

            return "Chrome"
        },
        GetRoAvatarData: async function(): Promise<RoAvatarData | Response | undefined> {
            if (CachedRoAvatarData) {
                return CachedRoAvatarData
            }

            const rbx = await API.Asset.GetRBX(FLAGS.ROAVATAR_DATA_URL)
            if (rbx instanceof Response) {
                warn(true, "Failed to get RoAvatarData", rbx)
                return rbx
            }

            const root = rbx.generateTree()
            const data = root.FindFirstChild("RoAvatarData")
            if (data) {
                const roavatarData = new RoAvatarData()
                roavatarData.fromInstance(data)
                CachedRoAvatarData = roavatarData
                return roavatarData
            }

            return undefined
        },
        JoinPlace: function(placeId: number) {
            window.location.href = `roblox://placeId=${placeId}`
        }
    },
    "Auth": {
        GetAuth: async function() {
            const auth = new Authentication()

            return auth
        }
    },
    "Economy": {
        GetAssetDetails: async function(assetId: number) {
            return RBLXGet("https://economy.roblox.com/v2/assets/" + assetId + "/details")
        }
    },
    "Avatar": {
        WearOutfit: async function(auth: Authentication, outfit: Outfit, onlyItems: boolean): Promise<[boolean, boolean]> {
            return new Promise((returnResolve) => {
                const promises: Promise<Response>[] = []

                if (!onlyItems) {
                    //scale
                    promises.push(new Promise((resolve) => {
                        RBLXPost("https://avatar.roblox.com/v1/avatar/set-scales", auth, outfit.scale.toJson()).then(response => {
                            resolve(response)
                        })
                    }))

                    //bodyColors
                    const isBrickColor = outfit.bodyColors.colorType == "BrickColor"
                    promises.push(new Promise((resolve) => {
                        RBLXPost(`https://avatar.roblox.com/${isBrickColor ? "v1" : "v2"}/avatar/set-body-colors`, auth, outfit.bodyColors.toJson()).then(response => {
                            resolve(response)
                        })
                    }))

                    //playerAvatarType
                    promises.push(new Promise((resolve) => {
                        RBLXPost("https://avatar.roblox.com/v1/avatar/set-player-avatar-type", auth, {"playerAvatarType": outfit.playerAvatarType}).then(response => {
                            resolve(response)
                        })
                    }))
                }

                //assets
                promises.push(new Promise((resolve) => {
                    let ogResponse: Response | undefined = undefined

                    RBLXPost("https://avatar.roblox.com/v2/avatar/set-wearing-assets", auth, {"assets": outfit.getAssetsJson()}).then(response => {
                        ogResponse = response
                        return response.json()
                    }).then(body => {
                        if (body.success == false) {
                            const currentAssets = outfit.getAssetsJson()

                            for (let i = 0; i < body.invalidAssetIds.length; i++) {
                                for (let j = 0; j < currentAssets.length; j++) {
                                    if (currentAssets[j].id == body.invalidAssetIds[i]) {
                                        currentAssets.splice(j,1)
                                    }
                                }
                            }

                            RBLXPost("https://avatar.roblox.com/v2/avatar/set-wearing-assets", auth, {"assets": currentAssets}).then(() => {
                                resolve(new Response("", {status:201}))
                            })
                        } else {
                            resolve(ogResponse || new Response("", {status: 200}))
                        }
                    })
                }))

                Promise.all<Response>(promises).then(values => {
                    let isSuccess = true
                    let failedToWearAll = false

                    for (const value of values) {
                        if (value.status !== 200 && value.status !== 201) {
                            isSuccess = false
                        }
                        if (value.status === 201) {
                            failedToWearAll = true
                        }
                    }

                    returnResolve([isSuccess, failedToWearAll])
                })
            })
        },
        SaveOutfitNoRetry: async function(auth: Authentication, outfit: Outfit) {
            const requestUrl = `https://avatar.roblox.com/${FLAGS.BODYCOLOR3 ? "v3" : "v2"}/outfits/create`

            return RBLXPost(requestUrl, auth, outfit.toCleanJson())
        },
        GetAvatarDetails: async function(userId: number) {
            let requestUrl = "https://avatar.roblox.com/v1/users/"
            
            if (FLAGS.BODYCOLOR3) {
                requestUrl = "https://avatar.roblox.com/v2/avatar/users/"
            }

            const response = await RBLXGet(requestUrl + userId + "/avatar")

            if (response.status == 200) {
                const responseBody = await response.json()

                const outfit = new Outfit()
                outfit.fromJson(responseBody)
                outfit.id = userId
                outfit.creatorId = userId
                outfit.origin = OutfitOrigin.WebAvatar

                return outfit
            } else {
                return response
            }
        },
        GetUserAvatarModel: async function(userId: number): Promise<Response | OutfitModel> {
            const response = await RBLXGet(`https://avatar.roblox.com/v4/avatar/users/${userId}?selectionTypes=0&selectionTypes=1&selectionTypes=2&selectionTypes=3&selectionTypes=4&selectionTypes=5&selectionTypes=6`)

            if (response.status !== 200) return response

            const body = await response.json() as AvatarModel_Result
            const outfitModel = new OutfitModel().fromJson(body)
            outfitModel.outfit.creatorId = userId
            outfitModel.outfit.origin = OutfitOrigin.WebAvatar
            return outfitModel
        },
        GetAvatarModel: async function(): Promise<Response | OutfitModel> {
            const userInfoPromise = API.Users.GetUserInfo()

            const response = await RBLXGet("https://avatar.roblox.com/v4/avatar?selectionTypes=0&selectionTypes=1&selectionTypes=2&selectionTypes=3&selectionTypes=4&selectionTypes=5&selectionTypes=6")

            if (response.status !== 200) return response

            const body = await response.json() as AvatarModel_Result
            const outfitModel = new OutfitModel().fromJson(body)

            const userInfo = await userInfoPromise
            if (userInfo) outfitModel.outfit.creatorId = userInfo.id
            outfitModel.outfit.origin = OutfitOrigin.WebAvatar
            
            return outfitModel
        },
        UpdateAvatarModel: async function(auth: Authentication, model: OutfitModel, updateTypes = AllAvatarModelOutfitUpdateTypes) {
            const response = await RBLXPatch("https://avatar.roblox.com/v4/avatar", auth, {
                updateTypes: updateTypes,
                avatarDefinition: {
                    updateAvatarConfig: {
                        backgroundRequestModel: {
                            id: model.background?.id || 0,
                        }
                    },
                    updateAvatarModel: model.outfit.toCleanJson()
                }
            })

            return response
        },
        GetOutfitModel: async function (id: number | string, creatorId: number): Promise<Response | OutfitModel> {
            const response = await RBLXGet(`https://avatar.roblox.com/v4/outfits/${id}/details`)

            if (response.status !== 200) return response

            const body = await response.json() as OutfitModel_Result
            const outfitModel = new OutfitModel().fromJson(body)
            outfitModel.outfit.origin = OutfitOrigin.WebOutfit
            outfitModel.outfit.id = Number(id)
            outfitModel.outfit.creatorId = creatorId
            return outfitModel
        },
        CreateOutfitModel: async function(auth: Authentication, model: OutfitModel) {
            const response = await RBLXPost("https://avatar.roblox.com/v4/outfits/create", auth, {
                outfitDefinition: {
                    updateOutfitConfig: {
                        backgroundRequestModel: {
                            id: model.background?.id || 0,
                        }
                    },
                    updateOutfitModel: model.outfit.toCleanJsonV4()
                }
            })

            return response
        },
        UpdateOutfitModel: async function(auth: Authentication, model: OutfitModel, id: number, updateTypes = AllAvatarModelOutfitUpdateTypes) {
            const response = await RBLXPatch(`https://avatar.roblox.com/v4/outfits/${id}`, auth, {
                updateTypes: updateTypes,
                outfitDefinition: {
                    updateOutfitConfig: {
                        backgroundRequestModel: {
                            id: model.background?.id || 0,
                        }
                    },
                    updateOutfitModel: model.outfit.toCleanJsonV4()
                }
            })

            return response
        },
        GetHeadShapes: async function(pageToken: string | null | undefined): Promise<AvatarInventory_Result | Response> {
            const itemSort = new ItemSort(1, "headshape")
            
            return API.Avatar.GetAvatarInventory("1", pageToken, [itemSort])
        },
        GetAvatarInventory: async function (sortOption: string, pageToken: string | null | undefined, itemInfos: ItemSort[] = []): Promise<AvatarInventory_Result | Response> {
            let requestUrl = "https://avatar.roblox.com/v1/avatar-inventory?"
            let needsAnd = false

            if (pageToken) {
                requestUrl += `${needsAnd?"&":""}pageToken=${pageToken}`
                needsAnd = true
            }

            if (sortOption) {
                requestUrl += `${needsAnd?"&":""}sortOption=${sortOption}`
                needsAnd = true
            }

            for (let i = 0; i < itemInfos.length; i++) {
                const itemInfo = itemInfos[i]
                requestUrl += `${needsAnd?"&":""}itemCategories[${i}].ItemSubType=${itemInfo.subType}&itemCategories[${i}].ItemType=${itemInfo.itemType}`
                needsAnd = true
            }

            if (pageToken) {
                const cache = CACHE.AvatarInventoryItem.get(requestUrl)
                if (cache !== undefined) {
                    return cache
                }
            }

            const response = await RBLXGet(requestUrl)
            if (response.status !== 200) {
                return response
            } else {
                const result = await response.json()

                //we dont cache for outfits because it can change easily without updating page token (you can change their names)
                if (pageToken && !requestUrl.includes("ItemType=Outfit")) {
                    CACHE.AvatarInventoryItem.set(requestUrl, result)
                }

                return result
            }
        },
        /**
         * @deprecated Use GetOutfitModel instead
         */
        GetOutfitDetails: async function(outfitId: number | string, userId: number): Promise<Response | Outfit> {
            let requestUrl = "https://avatar.roblox.com/v1/outfits/"

            if (FLAGS.BODYCOLOR3) {
                requestUrl = "https://avatar.roblox.com/v3/outfits/"
            }

            const response = await RBLXGet(requestUrl + outfitId + "/details")

            if (response.status == 200) {
                const responseJson = await response.json()

                const outfit = new Outfit()
                outfit.fromJson(responseJson)
                outfit.origin = OutfitOrigin.WebOutfit
                outfit.creatorId = userId

                return outfit
            } else {
                return response
            }
        },
        /**
         * @deprecated Use CreateOutfitModel instead
         */
        SaveOutfit: async function(auth: Authentication, outfit: Outfit) {
            const requestUrl = `https://avatar.roblox.com/${FLAGS.BODYCOLOR3 ? "v3" : "v2"}/outfits/create`

            const response = await RBLXPost(requestUrl, auth, outfit.toCleanJson())

            if (response.status === 200) {
                //AlertMessage("Successfully saved outfit to Roblox", false, 3000)
                return response
            } else if (response.status === 403) {
                //AlertMessage("Max outfits limit reached", true, 3000)
                return response
            } else {
                log(false, "Trying without unowned assets...")

                const response = await RBLXPost(requestUrl, auth, outfit.toCleanJson(true))
                /*if (response.status != 200) {
                    let body = response.json()
                    if (body) {
                        if (body.errors) {
                            if (body.errors[0]) {
                                if (body.errors[0].code == 0) {
                                    AlertMessage("Invalid outfit (Invalid assets)", true, 3000)
                                } else if (body.errors[0].code == 4) {
                                    AlertMessage("Invalid outfit (Invalid Name)", true, 3000)
                                } else {
                                    AlertMessage("Invalid outfit", true, 3000)
                                }
                            } else {
                                AlertMessage("Invalid outfit", true, 3000)
                            }
                        } else {
                            AlertMessage("Invalid outfit", true, 3000)
                        }
                    } else {
                        AlertMessage("Invalid outfit", true, 3000)
                    }
                } else {
                    AlertMessage("Successfully saved outfit to Roblox", false, 3000)
                }*/
                return response
            }

            return response
        },
        /**
         * @deprecated Use UpdateOutfitModel instead
         */
        UpdateOutfit: async function(auth: Authentication, outfitId: number | string, newOutfit: Outfit) {
            let requestUrl = "https://avatar.roblox.com/v1/outfits/"

            if (FLAGS.BODYCOLOR3) {
                requestUrl = "https://avatar.roblox.com/v3/outfits/"
            }
            
            requestUrl += outfitId

            const response = RBLXPatch(requestUrl, auth, JSON.stringify(newOutfit.toCleanJson()))

            return response
        },
        /**
         * @deprecated Use UpdateOutfitModel instead
         */
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        PatchOutfit: async function(auth: Authentication, outfitId: number | string, patchData: any) {
            let requestUrl = "https://avatar.roblox.com/v1/outfits/"

            if (FLAGS.BODYCOLOR3) {
                requestUrl = "https://avatar.roblox.com/v3/outfits/"
            }
            
            requestUrl += outfitId

            const response = RBLXPatch(requestUrl, auth, JSON.stringify(patchData))

            return response
        },
        DeleteOutfit: async function(auth: Authentication, outfitId: number | string) {
            return await RBLXPost(`https://avatar.roblox.com/v1/outfits/${outfitId}/delete`, auth, "")
        },
        GetUserOutfits: async function(userId: number): Promise<Response | GetUserOutfits_Result> {
            const response = await RBLXGet(`https://avatar.roblox.com/v2/avatar/users/${userId}/outfits?isEditable=true&itemsPerPage=1000&page=1`)
            if (response.status !== 200) {
                return response
            }

            const body = await response.json()
            return body as GetUserOutfits_Result
        },
        GetEmotes: async function(): Promise<Response> {
            return await RBLXGet("https://avatar.roblox.com/v1/emotes")
        },
        EquipEmote: async function(auth: Authentication, assetId: number | string, slot: number): Promise<Response> {
            return await RBLXPost(`https://avatar.roblox.com/v1/emotes/${assetId}/${slot}`, auth, "")
        },
        UnequipEmote: async function(auth: Authentication, slot: number): Promise<Response> {
            return await RBLXDelete(`https://avatar.roblox.com/v1/emotes/${slot}`, auth, "")
        },
        GetAvatarRules: async function(): Promise<Response> {
            return await RBLXGet("https://avatar.roblox.com/v1/avatar-rules")
        },
        RedrawThumbnail: async function(auth: Authentication): Promise<Response> {
            return await RBLXPost("https://avatar.roblox.com/v1/avatar/redraw-thumbnail", auth, "")
        },
        GetThumbnailCustomizations: async function(): Promise<Response | ThumbnailCustomizations_Result> {
            const response = await RBLXGet("https://avatar.roblox.com/v1/avatar/thumbnail-customizations")
            if (response.status !== 200) return response

            return (await response.json()) as ThumbnailCustomizations_Result
        },
        SetThumbnailCustomization: async function(auth: Authentication, body: ThumbnailsCustomization_Payload): Promise<Response> {
            return await RBLXPost("https://avatar.roblox.com/v1/avatar/thumbnail-customization", auth, body)
        },
        ResetThumbnailCustomization: async function(auth: Authentication, thumbnailType: number): Promise<Response> {
            return API.Avatar.SetThumbnailCustomization(auth, {
                thumbnailType: thumbnailType,
                emoteAssetId: 0,
                camera: {
                    fieldOfViewDeg: 30,
                    yRotDeg: 0,
                    distanceScale: -1,
                }
            })
        }
    },
    "Asset": {
        GetAssetBuffer: async function(url: string, headers?: HeadersInit, extraStr?: string): Promise<Response | ArrayBuffer> {
            let cacheStr = API.Misc.parseAssetString(url) || url
            if (headers) {
                cacheStr += JSON.stringify(headers)
            }
            if (extraStr) {
                cacheStr += extraStr
            }

            const cachedBuffer = CACHE.AssetBuffer.get(cacheStr)
            if (cachedBuffer) {
                return cachedBuffer
            } else {
                const promise = new Promise<ArrayBuffer | Response>((resolve) => {
                    getAssetBufferInternal(url, headers, extraStr).then((result) => {
                        resolve(result)
                    })
                })

                if (FLAGS.ENABLE_API_CACHE) {
                    CACHE.AssetBuffer.set(cacheStr, promise)
                }

                return promise
            }
        },
        /**
         * Remember to call .Destroy() on the Instance returned by RBX.generateTree() to avoid memory leaks
         * @param url 
         * @param headers 
         * @param contentRepresentationPriorityList 
         * @returns 
         */
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        GetRBX: async function(url: string, headers?: HeadersInit, contentRepresentationPriorityList?: any): Promise<Response | RBX> {
            const fetchStr = url

            let cacheStr = fetchStr
            if (headers) {
                cacheStr += JSON.stringify(headers)
            }
            const contentRepresentationPriorityListBASE64 = contentRepresentationPriorityList ? btoa(JSON.stringify(contentRepresentationPriorityList)) : undefined
            if (contentRepresentationPriorityListBASE64) {
                cacheStr += contentRepresentationPriorityListBASE64
            }

            const cachedRBX = CACHE.RBX.get(cacheStr)
            if (cachedRBX) {
                return cachedRBX.clone()
            } else {
                let extraStr = ""
                if (contentRepresentationPriorityListBASE64) {
                    extraStr += `&contentRepresentationPriorityList=${contentRepresentationPriorityListBASE64}`
                }

                const response = await this.GetAssetBuffer(fetchStr, headers, extraStr)
                if (response instanceof ArrayBuffer) {
                    const buffer = response
                    const rbx = new RBX()
                    try {
                        rbx.fromBuffer(buffer)
                    } catch {
                        return new Response()
                    }
                    if (FLAGS.ENABLE_API_CACHE && FLAGS.ENABLE_API_RBX_CACHE) {
                        CACHE.RBX.set(cacheStr, rbx.clone())
                    }
                    return rbx
                } else {
                    return response
                }
            }
        },
        GetMesh: async function(url: string, headers?: HeadersInit, readOnly: boolean = false): Promise<FileMesh | Response> {
            const fetchStr = url

            let cacheStr = fetchStr
            if (headers) {
                cacheStr += JSON.stringify(headers)
            }

            const cachedMesh = CACHE.Mesh.get(cacheStr)
            if (cachedMesh) {
                if (readOnly) {
                    return cachedMesh
                } else {
                    return cachedMesh.clone()
                }
            } else {
                const response = await this.GetAssetBuffer(fetchStr, headers)
                if (response instanceof ArrayBuffer) {
                    const buffer = response
                    const mesh = new FileMesh()
                    try {
                        await mesh.fromBuffer(buffer)
                        if (FLAGS.ENABLE_API_CACHE && FLAGS.ENABLE_API_MESH_CACHE) {
                            CACHE.Mesh.set(cacheStr, readOnly ? mesh : mesh.clone())
                        }
                        return mesh
                    } catch { //just return a response because draco decode or something else might fail
                        warn(true, "Failed to get mesh, mesh.fromBuffer failed, is DracoDecoderModule available?")
                        return new Response()
                    }
                } else {
                    warn(true, "Failed to get mesh, response was not an ArrayBuffer")
                    return response
                }
            }
        },
        GetAssetTypeId: async function (assetId: string | number): Promise<number | Response> {
            const response = await RBLXGet("https://assetdelivery.roblox.com/v2/asset?id=" + assetId)
            if (response.status !== 200) {
                return response
            }

            const body = await response.json()
            return body.assetTypeId
        },
        IsLayered: async function(id: number): Promise<boolean | Response> {
            const cached = CACHE.IsLayered.get(id)
            if (cached !== undefined) {
                return cached
            }

            const result = await API.Asset.GetRBX(`rbxassetid://${id}`, undefined)
            if (result instanceof RBX) {
                const dataModel = result.generateTree()
                const descendants = dataModel.GetDescendants()
                let hasWrapLayer = false

                for (const child of descendants) {
                    if (child.className === "WrapLayer") {
                        hasWrapLayer = true
                    }
                }

                CACHE.IsLayered.set(id, hasWrapLayer)

                dataModel.Destroy()

                return hasWrapLayer
            } else {
                warn(true, "Failed to get accessory")
                return result
            }
        }
    },
    "Catalog": {
        GetNavigationMenuItems: async function() {
            const response = await RBLXGet("https://catalog.roblox.com/v1/search/navigation-menu-items")

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as NavigationMenuItems
        },
        GetTopics: async function(auth: Authentication, body: GetTopics_Payload) {
            const response = await RBLXPost("https://catalog.roblox.com/v1/search/navigation-menu-items", auth, body)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as GetTopics_Result
        },
        Search: async function({taxonomy, salesTypeFilter = 1, sortType, categoryFilter, keyword, topics, creatorName, minPrice, maxPrice, includeNotForSale, limit = 120}: Search_Payload, cursor?: string) {
            /*https://catalog.roblox.com/v2/search/items/details?
            keyword=mariah&
            TriggeredByTopicDiscovery=true&
            topics=steven&
            taxonomy=u5jaNLyf2ZhvR95GS37ui5&
            creatorName=roblox&
            minPrice=1&
            salesTypeFilter=2&
            sortType=3&
            includeNotForSale=true&
            limit=120*/
            let url = `https://catalog.roblox.com/v2/search/items/details?taxonomy=${taxonomy}&salesTypeFilter=${salesTypeFilter}&`
            if (sortType !== undefined) url += `sortType=${sortType}&`
            if (categoryFilter !== undefined) url += `categoryFilter=${categoryFilter}&`
            if (keyword !== undefined) url += `keyword=${keyword}&`
            if (topics !== undefined) {
                let topicsStr = ""

                for (const topic of topics) {
                    if (topicsStr.length < 1) {
                        topicsStr += topic
                    } else {
                        topicsStr += " " + topic
                    }
                }

                url += `topics=${topicsStr}&`
            }
            if (creatorName !== undefined) url += `creatorName=${creatorName}&`
            if (minPrice !== undefined) url += `minPrice=${minPrice}&`
            if (maxPrice !== undefined) url += `maxPrice=${maxPrice}&`
            if (includeNotForSale !== undefined) url += `includeNotForSale=${includeNotForSale}&`
            if (cursor !== undefined) url += `cursor=${cursor}&`
            url += `limit=${limit}`

            const response = await RBLXGet(url)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as Search_Result
        },
        GetBundleDetails: async function(bundleId: number | string) {
            const response = await RBLXGet(`https://catalog.roblox.com/v1/catalog/items/${bundleId}/details?itemType=Bundle`)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as BundleDetails_Result
        },
        GetItemDetails: async function(auth: Authentication, items: {itemType: "Asset" | "Bundle", id: number}[]) {
            const finalResult: ItemDetails_Result = {
                data: []
            }

            for (let i = items.length - 1; i >= 0; i--) {
                const item = items[i]

                const cacheDetail = CACHE.ItemDetails.get(item.itemType + item.id)
                if (cacheDetail) {
                    finalResult.data.push(cacheDetail)
                    items.splice(items.indexOf(item), 1)
                }
            }

            if (items.length > 0) {
                const response = await RBLXPost(`https://catalog.roblox.com/v1/catalog/items/details`, auth, {
                    items
                })

                if (response.status !== 200) {
                    return response
                }

                const result = await response.json() as ItemDetails_Result

                for (const itemDetail of result.data) {
                    CACHE.ItemDetails.set(itemDetail.itemType + itemDetail.id, itemDetail)
                }

                finalResult.data = finalResult.data.concat(result.data)
            }

            return finalResult
        },
        GetMarketplaceWidgetsSearch: async function(query: string) {
            const response = await RBLXGet(`https://apis.roblox.com/marketplace-widgets/v1/widgets/search?query=${query}`)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as MarketplaceWidgets_Result
        },
        GetMarketplaceWidgets: async function(context?: string) { //context=avatarTab (does work. great!!!)
            let url = `https://apis.roblox.com/marketplace-widgets/v1/widgets`
            if (context) {
                url += `?context=${context}`
            }

            const response = await RBLXGet(url)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as MarketplaceWidgets_Result
        },
        //https://apis.roblox.com/marketplace-widgets/v1/pills
    },
    "Develop": {
        GetLatestVersions: async function(auth: Authentication, assetIds: number[]): Promise<Response | LatestVersions_Result> {
            const response = await RBLXPost("https://develop.roblox.com/v1/assets/latest-versions", auth, {
                assetIds,
                versionStatus: "Any"
            })

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as LatestVersions_Result
        }
    },
    "Inventory": {
        GetInventory: async function(userId: number, assetType: number, cursor?: string): Promise<Response> {
            let requestUrl = `https://inventory.roblox.com/v2/users/${userId}/inventory/${assetType}?sortOrder=Desc&limit=100`

            if (cursor) {
                requestUrl += `&cursor=${cursor}`
            }

            return RBLXGet(requestUrl)
        },
        IsItemOwned: async function(userId: number, itemType: string, assetId: number) {
            const cacheResult = CACHE.ItemOwned.get(`${userId}.${itemType}.${assetId}`)
            if (cacheResult) {
                if (cacheResult[0]) return true

                if ((Date.now() / 1000 - cacheResult[1]) < 10) return false
            }

            const response = await RBLXGet(`https://inventory.roblox.com/v1/users/${userId}/items/${itemType}/${assetId}/is-owned`)
         
            if (response.status !== 200) {
                return response
            }

            const responseBool = await response.json() as boolean

            if (responseBool) {
                CACHE.ItemOwned.set(`${userId}.${itemType}.${assetId}`, [true, 0])
            } else {
                CACHE.ItemOwned.set(`${userId}.${itemType}.${assetId}`, [false, Date.now() / 1000])
            }

            return responseBool
        }
    },
    "Users": {
        GetUserInfo: async function() {
            if (CACHE.UserInfo !== undefined) {
                return CACHE.UserInfo as UserInfo | Promise<UserInfo | undefined>
            }

            const promise = new Promise<UserInfo | undefined>((resolve) => {
                RBLXGet("https://users.roblox.com/v1/users/authenticated").then((response => {
                    if (response.status === 200) {
                        response.json().then((result) => {
                            (CACHE.UserInfo as UserInfo | Promise<UserInfo | undefined> | undefined) = result
                            resolve(result)
                        })
                    } else {
                        warn(true, "Failed to get user info: GetUserInfo(auth)")
                        resolve(undefined)
                    }
                }))
            });
            (CACHE.UserInfo as UserInfo | Promise<UserInfo | undefined> | undefined) = promise

            return promise
        },
        GetIdsFromUsernames: async function(usernames: string[]) {
            const response = await RBLXPost("https://users.roblox.com/v1/usernames/users", undefined, {"usernames": usernames})
            if (response.status !== 200) {
                return response
            }

            const body = await response.json()

            return body
        },
        GetInfoForId: async function(userId: number) {
            const response = await RBLXGet(`https://users.roblox.com/v1/users/${userId}`)
            if (response.status !== 200) {
                return response
            }

            const body = await response.json()
            return body as GetInfoForId_Result
        },
        UserOmniSearch: async function(query: string, cursor: string = ""): Promise<Response | UserOmniSearch_Result> {
            const response = await RBLXGet(`https://apis.roblox.com/search-api/omni-search?verticalType=user&searchQuery=${query}&pageToken=${cursor}&globalSessionId=${generateUUIDv4()}&sessionId=${generateUUIDv4()}`)
            if (response.status !== 200) return response

            const body = await response.json()
            return body as UserOmniSearch_Result
        }
    },
    "Thumbnails": {
        GetThumbnail: function(auth: Authentication, type: string, id: number | string, size: string = "150x150", headShape?: string): Promise<string | undefined> {
            startBatchThumbnails()
            
            const thisThumbnailInfo: ThumbnailInfo = {
                auth: auth,
                type: type,
                id: id,
                size: size,
                attempt: 0,
                resolves: [],
                lastTryTimestamp: 0,
                headShape: headShape,
                includeBackground: thumbnailTypesWithBackground.includes(type),
            }

            const cachedThumbnail = CACHE.Thumbnails.get(requestIdFromThumbnailInfo(thisThumbnailInfo))
            if (CACHE.Thumbnails.has(requestIdFromThumbnailInfo(thisThumbnailInfo))) {
                return new Promise(resolve => {
                    resolve(cachedThumbnail)
                })
            }
            
            for (const thumbnailInfo of ThumbnailsToBatch) {
                if (requestIdFromThumbnailInfo(thumbnailInfo) === requestIdFromThumbnailInfo(thisThumbnailInfo)) {
                    return new Promise(resolve => {
                        thumbnailInfo.resolves.push(resolve)
                    })
                }
            }

            return new Promise(resolve => {
                ThumbnailsToBatch.push({
                    auth: auth,
                    type: type,
                    id: id,
                    size: size,
                    resolves: [resolve],
                    attempt: 0,
                    lastTryTimestamp: 0,
                    headShape: headShape,
                    includeBackground: thumbnailTypesWithBackground.includes(type)
                })
            })
        },
        UncacheThumbnail: function(type: string, id: number | string, size: string = "150x150", headShape?: string) {
            const thisThumbnailInfo: ThumbnailInfo = {
                auth: new Authentication(),
                type: type,
                id: id,
                size: size,
                attempt: 0,
                resolves: [],
                lastTryTimestamp: 0,
                headShape: headShape,
                includeBackground: thumbnailTypesWithBackground.includes(type)
            }

            CACHE.Thumbnails.delete(requestIdFromThumbnailInfo(thisThumbnailInfo))
        },
        RenderOutfit: async function(auth: Authentication, outfit: Outfit, size: string = "150x150", thumbnailType: string = "2dWebp", attempt: number = 0): Promise<string | undefined> {
            return new Promise((resolve) => {
                if (attempt > 3) {
                    resolve(undefined)
                    return
                }

                const bodyToUse = {
                    "thumbnailConfig":{
                        "thumbnailId": 3,
                        "thumbnailType": thumbnailType,
                        "size": size
                    },
                    "avatarDefinition":{
                        "assets": outfit.getAssetsJson(),
                        "bodyColors":outfit.bodyColors.toHexJson(),
                        "scales":outfit.scale.toJson(),
                        "playerAvatarType":{
                            "playerAvatarType":outfit.playerAvatarType
                        }
                    }
                }

                RBLXPost("https://avatar.roblox.com/v1/avatar/render", auth, bodyToUse).then(data => {
                    return data.json()
                }).then(body => {
                    if (body.state != "Pending") {
                        resolve(body.imageUrl)
                    } else {
                        setTimeout(() => {
                            resolve(API.Thumbnails.RenderOutfit(auth, outfit, size, thumbnailType, attempt + 1))
                        }, 1000 + attempt * 1000)
                    }
                })
            })
        }
    },
    "LocalOutfit": {
        GetLocalOutfits: async function(): Promise<LocalOutfit[]> {
            const data = await (chrome || browser).storage.local.get(["localOutfits"])
            const localOutfitJsons = data["localOutfits"] as LocalOutfitJson[]
            if (!localOutfitJsons) {
                return []
            }

            const localOutfits: LocalOutfit[] = []
            for (const json of localOutfitJsons) {
                localOutfits.push(new LocalOutfit(new Outfit()).fromJson(json))
            }
            return localOutfits
        },
        SetLocalOutfits: async function(localOutfits: LocalOutfit[]): Promise<undefined> {
            const localOutfitsJson: LocalOutfitJson[] = []
            for (const localOutfit of localOutfits) {
                localOutfitsJson.push(localOutfit.toJson())
            }
            await (chrome || browser).storage.local.set({"localOutfits": localOutfitsJson})
        }
    },
    "Looks": {
        GetLook: async function(lookId: string): Promise<Response | Look_Result> {
            const response = await RBLXGet(`https://apis.roblox.com/look-api/v2/looks/${lookId}`)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as Look_Result
        },
        GetUserLooks: async function(userId: number, cursor?: string): Promise<Response | UserLooks_Result> {
            let url = `https://apis.roblox.com/look-api/v1/users/${userId}/looks?limit=50`

            if (cursor) {
                url += `&cursor=${cursor}`
            }

            const response = await RBLXGet(url)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as UserLooks_Result
        },
        CreateLook: async function(auth: Authentication, outfit: Outfit, name: string, description: string): Promise<Response> {
            let bodyColors = outfit.bodyColors
            if (bodyColors instanceof BodyColors) {
                bodyColors = bodyColors.toColor3()
            }

            const body = {
                name,
                description,
                displayProperties: null,
                avatarProperties: {
                    playerAvatarType: outfit.playerAvatarType,
                    scale: outfit.scale.toJson(),
                    bodyColor3s: bodyColors.toJson()
                },
                assets: outfit.getAssetsJson(),
            }

            const response = await RBLXPost("https://apis.roblox.com/look-api/v1/looks/create", auth, body)

            return response
        },
        DeleteLook: async function(auth: Authentication, lookId: string): Promise<Response> {
            const response = await RBLXDelete(`https://apis.roblox.com/look-api/v1/looks/${lookId}`, auth, {})

            return response
        },
        PatchLook: async function(auth: Authentication, lookId: string, data: Partial<Look_Result["look"]>): Promise<Response> {
            const response = await RBLXPatch(`https://apis.roblox.com/look-api/v1/looks/${lookId}`, auth, data)

            return response
        }
    },
    "PremiumFeatures": {
        GetSubscription: async function(userId: number): Promise<Response | GetSubscription_Result> {
            const response = await RBLXGet(`https://premiumfeatures.roblox.com/v1/users/${userId}/subscriptions`)

            if (response.status !== 200) {
                return response
            }

            return (await response.json()) as GetSubscription_Result
        }
    },
    "Subscriptions": {
        HasPlus: async function(): Promise<Response | boolean> {
            const response = await RBLXGet("https://apis.roblox.com/subscriptions/v2/user/subscriptions?ProductType=Blackbird&ResultsPerPage=1")
            if (response.status !== 200) {
                return response
            }

            return (await response.json()).subscriptions.length > 0
        }
    },
    "AvatarAIGenerationService": {
        GenerateBackground: async function(auth: Authentication, prompt: string): Promise<Response | string> {
            const response = await RBLXPost("https://apis.roblox.com/avatar-ai-generation-service/v1/backgrounds/generation", auth, {
                prompt
            })
            if (response.status !== 200 && response.status !== 202) {
                return response
            }

            const result = await response.json()
            if (result.generationId) {
                return result.generationId
            } else {
                return response
            }
        },
        GetBackground: async function(generationId: string): Promise<Response | GetBackground_Result> {
            const response = await RBLXGet(`https://apis.roblox.com/avatar-ai-generation-service/v1/backgrounds/generation/${generationId}`)
            if (response.status !== 200) {
                return response
            }

            return await response.json() as GetBackground_Result
        },
        UploadBackground: async function(auth: Authentication, generationId: string, displayName: string, description?: string): Promise<Response | string> {
            const response = await RBLXPost(`https://apis.roblox.com/avatar-ai-generation-service/v1/backgrounds/generation/${generationId}/upload`, auth, {
                displayName, //max 50 characters
                description //max 500 characters
            })
            if (response.status !== 200) {
                return response
            }

            const result = await response.json()
            if (result.operationId) {
                return result.operationId
            } else {
                return response
            }
        }
    },
    "RBLXGet": RBLXGet,
    "RBLXPost": RBLXPost,
    "RBLXDelete": RBLXDelete,
    "RBLXPatch": RBLXPatch
}

let currentLoadingThumbnails = false
function requestIdFromThumbnailInfo(thumbnailInfo: ThumbnailInfo) {
    let requestId = thumbnailInfo.id + ":undefined:" + thumbnailInfo.type + ":" + thumbnailInfo.size + ":webp:regular"
    if (thumbnailInfo.headShape) {
        requestId += `:${thumbnailInfo.headShape}`
    }
    if (thumbnailInfo.includeBackground) {
        requestId += `:${thumbnailInfo.includeBackground}`
    }
    return requestId
}

function PurgeFailedThumbnails() {
    ThumbnailsToBatch = ThumbnailsToBatch.filter((val) => {
        const cachedThumbnail = CACHE.Thumbnails.get(requestIdFromThumbnailInfo(val))
        const shouldPurge = val.attempt > 3 || cachedThumbnail
        if (shouldPurge && !cachedThumbnail) {
            if (FLAGS.ENABLE_API_CACHE) {
                CACHE.Thumbnails.set(requestIdFromThumbnailInfo(val), undefined)
            }

            for (const resolve of val.resolves) {
                resolve(undefined)
            }
        }

        return val.attempt <= 3 && !CACHE.Thumbnails.get(requestIdFromThumbnailInfo(val))
    })
}

function BatchThumbnails() {
    let auth: Authentication | undefined = undefined
    const body = []
    for (const thumbnailInfo of ThumbnailsToBatch) {
        if (Date.now() / 1000 - thumbnailInfo.lastTryTimestamp < 1 + thumbnailInfo.attempt) {
            continue
        }

        body.push({
            "format": "webp",
            "requestId": requestIdFromThumbnailInfo(thumbnailInfo),
            "size": thumbnailInfo.size,
            "targetId": thumbnailInfo.id,
            "type": thumbnailInfo.type,
            "headShape": thumbnailInfo.headShape,
            "includeBackground": thumbnailInfo.includeBackground,
        })

        auth = thumbnailInfo.auth

        thumbnailInfo.lastTryTimestamp = Date.now() / 1000
        thumbnailInfo.attempt++

        if (body.length >= 30) {
            break
        }
    }

    if (body.length > 0 && auth) {
        currentLoadingThumbnails = true
        RBLXPost("https://thumbnails.roblox.com/v1/batch", auth, body).then((response) => {
            if (response.status === 200) {
                response.json().then(body => {
                    for (const result of body.data) {
                        for (const thumbnailInfo of ThumbnailsToBatch) {
                            if (requestIdFromThumbnailInfo(thumbnailInfo) === result.requestId) {
                                if (result.state === "Completed") {
                                    for (const resolve of thumbnailInfo.resolves) {
                                        if (FLAGS.ENABLE_API_CACHE) {
                                            CACHE.Thumbnails.set(result.requestId, result.imageUrl)
                                        }
                                        resolve(result.imageUrl)
                                        thumbnailInfo.attempt = 999
                                    }
                                } else if (result.state !== "Pending") {
                                    thumbnailInfo.attempt = 999
                                }
                            }
                        }
                    }
                })
            }
        }).finally(() => {
            PurgeFailedThumbnails()
            currentLoadingThumbnails = false
        })
    }
}

let batchThumbnailsInterval: NodeJS.Timeout | undefined = undefined
function startBatchThumbnails() {
    if (batchThumbnailsInterval) return

    batchThumbnailsInterval = setInterval(() => {
        if (!currentLoadingThumbnails) {
            BatchThumbnails()
        }
    },10)
}