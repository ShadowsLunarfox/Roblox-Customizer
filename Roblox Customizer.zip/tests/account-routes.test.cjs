const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');

const startup = fs.readFileSync(path.join(__dirname, '..', 'src/shared/startup.js'), 'utf8');
const settings = fs.readFileSync(path.join(__dirname, '..', 'src/settings/settings.js'), 'utf8');
const fallbackStart = settings.indexOf('  function syncFrostPage()');
const fallbackEnd = settings.indexOf('  function openDatabase()', fallbackStart);
assert.ok(fallbackStart >= 0 && fallbackEnd > fallbackStart);
const fallback = settings.slice(fallbackStart, fallbackEnd);

function harness(url, script, cached = null) {
  const attributes = new Map();
  const properties = new Map();
  const root = {
    dataset: {}, style: { setProperty(name, value) { properties.set(name, value); } },
    setAttribute(name, value) { attributes.set(name, value); },
    getAttribute(name) { return attributes.get(name) ?? null; },
    hasAttribute(name) {
      return name === 'data-rc-frost-page' ? root.dataset.rcFrostPage !== undefined : attributes.has(name);
    },
    removeAttribute(name) {
      if (name === 'data-rc-frost-page') delete root.dataset.rcFrostPage;
      else attributes.delete(name);
    },
    toggleAttribute(name, enabled) {
      if (enabled) root.setAttribute(name, '');
      else root.removeAttribute(name);
    }
  };
  const events = new Map();
  const location = new URL(url, 'https://www.roblox.com');
  const context = {
    location,
    document: { documentElement: root, readyState: 'loading',
      addEventListener() {}, querySelector() { return null; } },
    localStorage: { getItem() { return cached && JSON.stringify(cached); }, setItem() {} },
    MutationObserver: class { observe() {} },
    addEventListener(name, callback) { events.set(name, callback); },
    setTimeout() { return 1; }, clearTimeout() {}
  };
  vm.runInNewContext(script, context);
  return { root, properties, location, events, startup: context.RobloxCustomizerStartup };
}

for (const [name, script] of [['startup', startup], ['settings fallback', fallback]]) {
  test(`${name} enables interface customization on a fresh install without a wallpaper`, () => {
    for (const route of ['/home', '/games/4623386862/Piggy', '/my/avatar', '/my/account',
      '/catalog', '/charts', '/upgrades/robux', '/report-abuse', '/transactions',
      '/game-pass/1903230850/Admin-Commands', '/badges/2526706651131685/You-played']) {
      const env = harness(route, script);
      assert.equal(env.root.hasAttribute('data-rc-ui-active'), true, route);
      assert.equal(env.root.hasAttribute('data-rc-background-active'), false, route);
    }
  });

  test(`${name} styles game and user search independently of the keyword and clears the style on navigation`, () => {
    const env = harness('/discover/?keyword=mm2', script);
    for (const [url, expected] of [
      ['/discover/?keyword=mm2', 'game-search'], ['/discover?keyword=%E6%B8%B8%E6%88%8F', 'game-search'],
      ['/DISCOVER/', 'game-search'], ['/search/users?keyword=blue%27', 'user-search'],
      ['/search/users/?keyword=%E7%8E%A9%E5%AE%B6', 'user-search'], ['/SEARCH/USERS', 'user-search'],
      ['/charts', 'charts'], ['/search/communities?keyword=blue', 'community-search'],
      ['/discover-extra', undefined], ['/discover/details', undefined],
      ['/search/users-extra', undefined], ['/search/users/123', undefined],
      ['/users/123/profile', 'profile'], ['/home', undefined]
    ]) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, expected, url);
      assert.equal(env.root.hasAttribute('data-rc-ui-active'), true);
      assert.equal(env.root.hasAttribute('data-rc-background-active'), false);
    }
  });

  test(`${name} limits private-server configuration styling to native configuration routes`, () => {
    const env = harness('/private-server/configure/4169319554', script);
    for (const url of ['/private-server/configure/4169319554', '/private-server/configure/123/',
      '/PRIVATE-SERVER/CONFIGURE/123', '/private-server/configure?privateServerId=4169319554']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, 'private-server-configure', url);
      assert.equal(env.root.hasAttribute('data-rc-ui-active'), true);
      assert.equal(env.root.hasAttribute('data-rc-background-active'), false);
    }
    for (const url of ['/private-server/configure/nope', '/private-server/configure/123oops',
      '/private-server/configure/-123', '/private-server/configure/123/extra',
      '/private-server/configure-extra/123', '/private-server', '/NewLogin', '/home']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, undefined, url);
    }
  });

  test(`${name} applies the product style to bundle routes and clears it after navigation`, () => {
    const env = harness('/bundles/33230277606065/R6', script);
    assert.equal(env.root.dataset.rcFrostPage, 'catalog');
    for (const url of ['/catalog/10159600649/Crown', '/bundles/123', '/bundles/123/']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, 'catalog', url);
    }
    for (const url of ['/home', '/bundles', '/bundles-extra/123', '/bundles/nope', '/bundles/-123', '/bundles/123oops']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, undefined, url);
    }
  });

  test(`${name} styles game pass and badge details without enabling catalog previews`, () => {
    const env = harness('/game-pass/1903230850/Admin-Commands', script);
    for (const [url, expected] of [
      ['/game-pass/1903230850/Admin-Commands', 'game-pass'],
      ['/game-pass/123/', 'game-pass'],
      ['/GAME-PASS/123', 'game-pass'],
      ['/badges/2526706651131685/You-played', 'badge'],
      ['/badges/123?ref=game', 'badge'],
      ['/catalog/123/Item', 'catalog'],
      ['/home', undefined],
      ['/game-pass', undefined], ['/game-pass/nope', undefined],
      ['/game-pass/123oops', undefined], ['/game-pass/-123', undefined],
      ['/game-pass-extra/123', undefined], ['/badges', undefined],
      ['/badges/nope', undefined], ['/badges/123oops', undefined],
      ['/badges/-123', undefined], ['/badges-extra/123', undefined]
    ]) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, expected, url);
    }
  });

  test(`${name} marks own and user-specific friends and inventory URLs before content renders`, () => {
    for (const [url, expected] of [
      ['/users/friends#!/friend-requests', 'friends'],
      ['/users/156/friends#!/friends', 'friends'],
      ['/users/123456789/friends/', 'friends'],
      ['/users/inventory#!/accessories', 'inventory'],
      ['/users/156/inventory/#!/accessories', 'inventory'],
      ['/users/123456789/inventory/?category=accessories', 'inventory'],
      ['/my/messages/#!/inbox', 'messages'],
      ['/trades?tab=Inbound', 'trades'],
      ['/transactions?transactionType=Purchase', 'transactions'],
      ['/transactions/', 'transactions']
    ]) {
      assert.equal(harness(url, script).root.dataset.rcFrostPage, expected, url);
    }
  });

  test(`${name} styles report-abuse routes without matching sign-in or unrelated report URLs`, () => {
    for (const url of ['/report-abuse', '/report-abuse/', '/report-abuse/?targetId=118155665728354&abuseVector=place']) {
      assert.equal(harness(url, script).root.dataset.rcFrostPage, 'report-abuse', url);
    }
    const env = harness('/report-abuse/', script);
    for (const url of ['/newlogin?ReturnUrl=%2Freport-abuse', '/report-abuse-extra', '/report-abuse/details', '/home']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, undefined, url);
    }
  });

  test(`${name} limits the Robux redesign to the purchase overview`, () => {
    for (const url of ['/upgrades/robux', '/upgrades/robux/', '/upgrades/robux?ctx=navpopover', '/UPGRADES/ROBUX/']) {
      assert.equal(harness(url, script).root.dataset.rcFrostPage, 'robux', url);
    }
    const env = harness('/upgrades/robux?ctx=navpopover', script);
    for (const url of ['/upgrades/paymentmethods?ctx=subscription', '/upgrades/robux/checkout', '/upgrades/robux-extra', '/upgrades', '/newlogin', '/home']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, undefined, url);
    }
  });

  test(`${name} styles account settings tabs without matching sign-in or other account URLs`, () => {
    for (const url of ['/my/account#!/info', '/my/account/', '/MY/ACCOUNT?tab=info', '/my/account#!/security', '/my/account#!/privacy', '/my/account#!/billing']) {
      assert.equal(harness(url, script).root.dataset.rcFrostPage, 'account-settings', url);
    }
    const env = harness('/my/account#!/info', script);
    env.location.hash = '#!/security';
    env.events.get('hashchange')();
    assert.equal(env.root.dataset.rcFrostPage, 'account-settings');
    for (const url of ['/NewLogin?ReturnUrl=%2Fmy%2Faccount', '/my/account-extra', '/my/account/security', '/account', '/home']) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, undefined, url);
    }
  });

  test(`${name} retains page styling across native account tabs`, () => {
    for (const [url, expected, hashes] of [
      ['/users/156/friends', 'friends', ['#!/friends', '#!/followers', '#!/friend-requests']],
      ['/users/156/inventory/', 'inventory', ['#!/accessories', '#!/clothing', '#!/badges']],
      ['/my/messages/', 'messages', ['#!/inbox', '#!/sent', '#!/archive']],
      ['/transactions', 'transactions', ['#summary', '#purchases', '#sales']]
    ]) {
      const env = harness(url, script);
      for (const hash of hashes) {
        env.location.hash = hash;
        env.events.get('hashchange')();
        assert.equal(env.root.dataset.rcFrostPage, expected);
      }
    }
  });

  test(`${name} changes account markers during navigation and removes them on unrelated pages`, () => {
    const env = harness('/users/156/inventory/', script);
    for (const [url, expected] of [
      ['/users/156/friends', 'friends'],
      ['/trades?tab=Outbound', 'trades'],
      ['/my/messages/', 'messages'],
      ['/transactions', 'transactions'],
      ['/users/156/profile', 'profile'],
      ['/home', undefined]
    ]) {
      env.location.href = new URL(url, 'https://www.roblox.com').href;
      env.events.get('popstate')();
      assert.equal(env.root.dataset.rcFrostPage, expected, url);
    }
  });

  test(`${name} excludes malformed user IDs and similarly named routes`, () => {
    for (const url of ['/users/abc/inventory', '/users/-156/inventory',
      '/users/1.5/friends', '/users/156/friends-extra', '/users/156/inventory-extra',
      '/users/friends-extra', '/users/inventory-extra', '/trades-extra', '/my/messages-extra',
      '/transactions-extra', '/transactions/purchase', '/my/transactions']) {
      assert.equal(harness(url, script).root.dataset.rcFrostPage, undefined, url);
    }
  });
}

test('user-specific routes honor cached visual preferences and wallpaper can still be disabled', () => {
  const env = harness('/users/156/inventory/', startup, {
    version: 1, backgroundActive: true, glassBlur: 24, glassOpacity: 75
  });
  assert.equal(env.root.hasAttribute('data-rc-background-active'), true);
  assert.equal(env.properties.get('--rc-glass-blur'), '24px');
  assert.equal(env.properties.get('--rc-glass-opacity'), '0.75');
  env.startup.setPreferences({ source: 'none', glassBlur: 18, glassOpacity: 62 });
  assert.equal(env.root.hasAttribute('data-rc-background-active'), false);
  assert.equal(env.root.hasAttribute('data-rc-ui-active'), true);
  assert.equal(env.properties.get('--rc-glass-blur'), '18px');
  assert.equal(env.root.dataset.rcFrostPage, 'inventory');
  env.startup.setPreferences({ source: 'none', glassBlur: 32, glassOpacity: 85 });
  assert.equal(env.properties.get('--rc-glass-blur'), '32px');
  assert.equal(env.properties.get('--rc-glass-opacity'), '0.85');
  assert.equal(env.root.hasAttribute('data-rc-background-active'), false);
  assert.equal(env.root.hasAttribute('data-rc-ui-active'), true);
});

test('Effect switches default off, accept only booleans, and retain slider values through cache and route changes', () => {
  const normalize = normalizeSettings();
  for (const input of [undefined, {}, { disableTransparency: 'true', disableBlur: 1 }]) {
    const preferences = normalize(input);
    assert.equal(preferences.disableTransparency, false);
    assert.equal(preferences.disableBlur, false);
  }
  const cached = { version: 1, glassBlur: 24, glassOpacity: 75, disableTransparency: true, disableBlur: true };
  const env = harness('/home', startup, cached);
  const check = (transparency, blur) => {
    assert.equal(env.root.hasAttribute('data-rc-disable-transparency'), transparency);
    assert.equal(env.root.hasAttribute('data-rc-disable-blur'), blur);
    assert.equal(env.properties.get('--rc-glass-opacity'), transparency ? '1' : '0.75');
    assert.equal(env.properties.get('--rc-page-panel-opacity'), transparency ? '1' : '0.375');
    assert.equal(env.properties.get('--rc-glass-blur'), blur ? '0px' : '24px');
  };
  check(true, true);
  env.location.href = 'https://www.roblox.com/my/account#!/security';
  env.events.get('popstate')();
  check(true, true);
  env.startup.setPreferences({ ...cached, disableBlur: false });
  check(true, false);
  env.startup.setPreferences({ ...cached, disableTransparency: false });
  check(false, true);
  env.startup.setPreferences({ ...cached, disableTransparency: false, disableBlur: false });
  check(false, false);
});

test('Home visibility preferences are cached independently and missing flags remain visible', () => {
  const oldCache = harness('/home', startup, { version: 1, hideRecommended: true });
  assert.equal(oldCache.root.hasAttribute('data-rc-hide-recommended-upper'), true);
  assert.equal(oldCache.root.hasAttribute('data-rc-hide-recommended-lower'), true);
  assert.equal(oldCache.root.hasAttribute('data-rc-hide-favorites'), false);
  assert.equal(oldCache.root.hasAttribute('data-rc-hide-standout-games'), false);
  const env = harness('/home', startup, {
    version: 1, hideFavorites: true, hideStandoutGames: false,
    hideRecommended: true, hideRecommendedUpper: false, hideRecommendedLower: true
  });
  assert.equal(env.root.hasAttribute('data-rc-hide-favorites'), true);
  assert.equal(env.root.hasAttribute('data-rc-hide-standout-games'), false);
  assert.equal(env.root.hasAttribute('data-rc-hide-recommended-upper'), false, 'An explicit upper preference overrides the legacy switch');
  assert.equal(env.root.hasAttribute('data-rc-hide-recommended-lower'), true);
  env.startup.setPreferences({ hideFavorites: false, hideStandoutGames: true,
    hideRecommendedUpper: true, hideRecommendedLower: false });
  assert.equal(env.root.hasAttribute('data-rc-hide-favorites'), false);
  assert.equal(env.root.hasAttribute('data-rc-hide-standout-games'), true);
  assert.equal(env.root.hasAttribute('data-rc-hide-recommended-upper'), true);
  assert.equal(env.root.hasAttribute('data-rc-hide-recommended-lower'), false);
  assert.equal(env.root.hasAttribute('data-rc-hide-recommended'), false);
  const defaults = harness('/home', startup, { version: 1 });
  assert.equal(defaults.root.hasAttribute('data-rc-hide-recommended-upper'), false);
  assert.equal(defaults.root.hasAttribute('data-rc-hide-recommended-lower'), false);
});

function normalizeSettings() {
  const defaultsStart = settings.indexOf('  const FEED_PAGES =');
  const defaultsEnd = settings.indexOf('  let settings =', defaultsStart);
  const normalizeStart = settings.indexOf('  function currentSettings(');
  const normalizeEnd = settings.indexOf('  function syncFrostPage()', normalizeStart);
  assert.ok(defaultsStart >= 0 && defaultsEnd > defaultsStart && normalizeStart >= 0 && normalizeEnd > normalizeStart);
  return vm.runInNewContext(`${settings.slice(defaultsStart, defaultsEnd)}\n${settings.slice(normalizeStart, normalizeEnd)}\ncurrentSettings`);
}

test('Saved recommendation preferences migrate without overriding independent choices', () => {
  const normalize = normalizeSettings();
  for (const [saved, upper, lower] of [
    [undefined, false, false],
    [{ hideRecommended: true, hiddenRecommendedGames: [{ placeId: '102', name: 'Hidden game' }] }, true, true],
    [{ hideRecommended: false }, false, false],
    [{ hideRecommended: true, hideRecommendedUpper: false }, false, true],
    [{ hideRecommendedUpper: true, hideRecommendedLower: false }, true, false]
  ]) {
    const normalized = normalize(saved);
    assert.equal(normalized.hideRecommendedUpper, upper);
    assert.equal(normalized.hideRecommendedLower, lower);
    assert.equal(Object.hasOwn(normalized, 'hideRecommended'), false);
    if (saved?.hiddenRecommendedGames) assert.equal(normalized.hiddenRecommendedGames, saved.hiddenRecommendedGames);
  }
});

test('Social feeds migrate global visibility while preserving separate page and platform choices', () => {
  const normalize = normalizeSettings();
  for (const saved of [undefined, { hideXFeed: true }, { hideYouTubeFeed: true },
    { hideXFeed: true, hideYouTubeFeed: true, showGameXFeed: true, showProfileYouTubeFeed: true },
    { showGameYouTubeFeed: false, showCommunityXFeed: false, showProfileXFeed: 'invalid' }]) {
    const normalized = normalize(saved);
    assert.equal(Object.hasOwn(normalized, 'hideXFeed'), false);
    assert.equal(Object.hasOwn(normalized, 'hideYouTubeFeed'), false);
    for (const page of ['Game', 'Community', 'Profile']) for (const platform of ['X', 'YouTube']) {
      const key = `show${page}${platform}Feed`;
      const expected = typeof saved?.[key] === 'boolean' ? saved[key] : saved?.[`hide${platform}Feed`] !== true;
      assert.equal(normalized[key], expected, key);
    }
  }
});

test('Startup restores separate feed choices before rendering and retains them across page routes', () => {
  const preferences = { showGameXFeed: true, showGameYouTubeFeed: false,
    showCommunityXFeed: false, showCommunityYouTubeFeed: true,
    showProfileXFeed: false, showProfileYouTubeFeed: false };
  const env = harness('/games/123/Test', startup, { version: 1, ...preferences });
  const check = () => {
    for (const page of ['Game', 'Community', 'Profile']) for (const platform of ['X', 'YouTube']) {
      assert.equal(env.root.hasAttribute(`data-rc-hide-${page.toLowerCase()}-${platform.toLowerCase()}-feed`),
        !preferences[`show${page}${platform}Feed`]);
    }
  };
  check();
  for (const route of ['/communities/123/Test', '/groups/123/Test', '/users/123/profile', '/home']) {
    env.location.href = new URL(route, 'https://www.roblox.com').href;
    env.events.get('popstate')();
    check();
  }
  env.startup.setPreferences({ hideXFeed: true, hideYouTubeFeed: true, showCommunityXFeed: true });
  assert.equal(env.root.hasAttribute('data-rc-hide-game-x-feed'), true);
  assert.equal(env.root.hasAttribute('data-rc-hide-community-x-feed'), false);
  assert.equal(env.root.hasAttribute('data-rc-hide-profile-youtube-feed'), true);
  env.startup.setPreferences({});
  for (const page of ['game', 'community', 'profile']) for (const platform of ['x', 'youtube']) {
    assert.equal(env.root.hasAttribute(`data-rc-hide-${page}-${platform}-feed`), false);
  }
});

test('Custom colors require explicit opt-in and validate saved colors before caching or applying them', () => {
  const normalize = normalizeSettings();
  const defaults = normalize();
  assert.equal(defaults.experimentalCustomColors, false);
  const normalized = normalize({ experimentalCustomColors: 'true', customTextColor: '#AABBCC',
    customBackgroundColor: 'red; background: url(https://example.com)', customAccentColor: '#123' });
  assert.equal(normalized.experimentalCustomColors, false);
  assert.equal(normalized.customTextColor, '#aabbcc');
  assert.equal(normalized.customBackgroundColor, defaults.customBackgroundColor);
  assert.equal(normalized.customAccentColor, defaults.customAccentColor);
  const env = harness('/home', startup, { version: 1, customTextColor: '#123456' });
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), false);
  assert.equal(env.properties.get('--rc-custom-text'), '');
  env.startup.setPreferences({ experimentalCustomColors: true, customTextColor: '#AABBCC',
    customBackgroundColor: 'url(https://example.com)', customAccentColor: '#facc15' });
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), true);
  assert.equal(env.properties.get('--rc-custom-text'), '#aabbcc');
  assert.equal(env.properties.get('--rc-custom-text-rgb'), '170 187 204');
  assert.equal(env.properties.get('--rc-custom-background'), defaults.customBackgroundColor);
  assert.equal(env.properties.get('--rc-custom-accent-text'), '#000000');
  env.startup.setPreferences({ experimentalCustomColors: true, customBackgroundColor: '#ffffff', customAccentColor: '#2244aa' });
  assert.equal(env.properties.get('--rc-custom-color-scheme'), 'light');
  assert.equal(env.properties.get('--rc-custom-accent-text'), '#ffffff');
  env.startup.setPreferences({ experimentalCustomColors: false });
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), false);
  assert.equal(env.properties.get('--rc-custom-text'), '');
  assert.equal(env.properties.get('--rc-custom-background'), '');
  assert.equal(env.properties.get('--rc-custom-accent'), '');
});

test('An opted-in palette is restored from the appearance cache and retained across routes', () => {
  const env = harness('/home', startup, { version: 1, experimentalCustomColors: true,
    customTextColor: '#123456', customBackgroundColor: '#eef2ff', customAccentColor: '#facc15' });
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), true);
  assert.equal(env.properties.get('--rc-custom-background'), '#eef2ff');
  env.location.href = 'https://www.roblox.com/my/account#!/security';
  env.events.get('popstate')();
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), true);
  assert.equal(env.properties.get('--rc-custom-text'), '#123456');
  env.startup.setPreferences({});
  assert.equal(env.root.hasAttribute('data-rc-custom-colors'), false, 'Authoritative preferences can disable a cached palette');
});
