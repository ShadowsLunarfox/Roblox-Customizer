(globalThis.RobloxCustomizerCompatibility?.runFeature || (initialize => initialize()))(() => {
  'use strict';
  const routePath = value => globalThis.RobloxCustomizerRoutes?.pathname(value) ?? value ?? location.pathname;

  const HOME_CAROUSEL = 'WebHomeFriendsCarousel';
  const FIND_PATH = /^\/v1\/users\/\d+\/friends\/find\/?$/;
  const GAME_PATH = /^\/games\/\d+(?:\/|$)/;
  const INSTANCE_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const MAX_FRIENDS = 51;
  const MAX_PAGES = 20;
  const componentTypes = new WeakMap();
  const patchedMethods = new WeakMap();
  const watchedProperties = new WeakMap();
  const mountedServerAttributes = new WeakMap();
  let renderingFriends = null;

  function isHomeFriends(props) {
    return props?.carouselName === HOME_CAROUSEL && 'friendsList' in props;
  }

  function isServerList(props) {
    return GAME_PATH.test(routePath()) && !!props?.loadMoreGameInstances
      && 'headerTitle' in props;
  }

  function isServerCard(props) {
    return GAME_PATH.test(routePath()) && props && 'gameServerStatus' in props
      && typeof props.id === 'string' && INSTANCE_ID.test(props.id);
  }

  function isPrivateServerCard(props) {
    const placeId = Number(routePath().match(/^\/games\/(\d+)(?:\/|$)/)?.[1]);
    if (!placeId || !props || !Number.isSafeInteger(props.vipServerId) || props.vipServerId <= 0) return false;
    // The compact private-server row has no placeId, serverListType or
    // gameServerStatus props. Its numeric VIP identity distinguishes it from
    // the friend/public rows that share the same native component.
    return props.serverListType === 'private' && 'gameServerStatus' in props && props.placeId === placeId
      || typeof props.onJoinClick === 'function' && typeof props.playerCountStatus === 'string'
        && typeof props.name === 'string' && (props.placeId == null || props.placeId === placeId);
  }

  function exposePrivateServerIdentity(result, props) {
    const classes = result?.props?.className?.split(/\s+/) || [];
    const compact = typeof props.onJoinClick === 'function' && result?.type === 'div'
      && ['flex', 'items-center', 'justify-between', 'padding-y-medium', 'width-full']
        .every(name => classes.includes(name));
    if (!compact && !(result?.type === 'li' && classes.includes('rbx-private-game-server-item'))) return result;
    // Supply the numeric identity to the existing layout adapter. Native actions,
    // subscriptions, hooks and the component tree stay owned by Roblox.
    const next = { 'data-private-server-id': String(props.vipServerId) };
    if (compact) next['data-rc-private-server-compact'] = '';
    return typeof window.React?.cloneElement === 'function'
      ? window.React.cloneElement(result, next) : { ...result, props: { ...result.props, ...next } };
  }

  function mapElements(value, transform, depth = 0) {
    if (depth > 12) return value;
    if (Array.isArray(value)) {
      const next = value.map(item => mapElements(item, transform, depth + 1));
      return next.some((item, index) => item !== value[index]) ? next : value;
    }
    if (!value || typeof value !== 'object' || !value.props) return value;
    const props = value.props;
    const children = mapElements(props.children, transform, depth + 1);
    const updated = transform(value, props);
    if (!updated && children === props.children) return value;
    const nextProps = { ...props, ...updated };
    if (children !== props.children) nextProps.children = children;
    const clone = window.React?.cloneElement;
    return typeof clone === 'function' ? clone(value, nextProps) : { ...value, props: nextProps };
  }

  function exposeServerListMetrics(result, props) {
    if (!Array.isArray(props.gameInstances)) return result;
    const servers = new Map(props.gameInstances.filter(server =>
      typeof server?.id === 'string' && INSTANCE_ID.test(server.id))
      .map(server => [server.id.toLowerCase(), server]));
    if (!servers.size) return result;
    return mapElements(result, (_, elementProps) => {
      if (!isServerCard(elementProps)) return null;
      const server = servers.get(elementProps.id.toLowerCase());
      if (!server) return null;
      const metrics = {};
      if (typeof server.ping === 'number' && Number.isFinite(server.ping)) metrics.ping = server.ping;
      if (/^(?:Low|Medium|High)$/i.test(server.pingSignalLevel || '')) metrics.pingSignalLevel = server.pingSignalLevel;
      const country = server.serverLocation?.countryCode || server.location?.countryCode || server.countryCode;
      if (typeof country === 'string' && /^[a-z]{2}$/i.test(country)) metrics.countryCode = country.toUpperCase();
      if (Number.isSafeInteger(server.playing) && server.playing >= 0) metrics.playing = server.playing;
      if (Number.isSafeInteger(server.maxPlayers) && server.maxPlayers > 0) metrics.maxPlayers = server.maxPlayers;
      if (typeof server.fps === 'number' && Number.isFinite(server.fps) && server.fps >= 0 && server.fps <= 1000) metrics.fps = server.fps;
      if (Number.isSafeInteger(server.languageMatchCount) && server.languageMatchCount >= 0) metrics.languageMatchCount = server.languageMatchCount;
      for (const key of ['serverLocation', 'serverStartedAt']) if (server[key] != null) metrics[key] = server[key];
      return metrics;
    });
  }

  function serverMetricAttributes(props) {
    const next = { 'data-rc-instance-id': props.id.toLowerCase() };
    if (typeof props.ping === 'number' && Number.isFinite(props.ping)
      && props.ping > 0 && props.ping <= 10_000) next['data-rc-ping'] = Math.round(props.ping);
    const playing = props.playing ?? props.currentPlayersCount;
    if (Number.isSafeInteger(playing) && playing >= 0) next['data-rc-playing'] = playing;
    if (Number.isSafeInteger(props.maxPlayers) && props.maxPlayers > 0) next['data-rc-max-players'] = props.maxPlayers;
    if (typeof props.fps === 'number' && Number.isFinite(props.fps) && props.fps >= 0 && props.fps <= 1000) next['data-rc-server-fps'] = props.fps;
    if (Number.isSafeInteger(props.languageMatchCount) && props.languageMatchCount >= 0
      && (!Number.isSafeInteger(playing) || props.languageMatchCount <= playing)) next['data-rc-language-match-count'] = props.languageMatchCount;
    const serverLocation = props.serverLocation || props.location;
    if (typeof serverLocation?.city === 'string') next['data-rc-server-city'] = serverLocation.city.slice(0, 100);
    if (typeof serverLocation?.latitude === 'number' && Math.abs(serverLocation.latitude) <= 90) next['data-rc-server-latitude'] = serverLocation.latitude;
    if (typeof serverLocation?.longitude === 'number' && Math.abs(serverLocation.longitude) <= 180) next['data-rc-server-longitude'] = serverLocation.longitude;
    // A random UUID and the time we first see a server do not reveal its age.
    if (typeof props.serverStartedAt === 'number' && props.serverStartedAt > 0 && props.serverStartedAt <= Date.now()) {
      next['data-rc-server-started-at'] = props.serverStartedAt;
    }
    if (/^(?:Low|Medium|High)$/i.test(props.pingSignalLevel || '')) next['data-rc-ping-level'] = props.pingSignalLevel.toLowerCase();
    const country = props.serverLocation?.countryCode || props.location?.countryCode || props.countryCode;
    if (typeof country === 'string' && /^[a-z]{2}$/i.test(country)) next['data-country-code'] = country.toUpperCase();
    return next;
  }

  function exposeServerCardMetrics(result, props) {
    const attachToCard = !isPrivateServerCard(props);
    return mapElements(result, (element, elementProps) => {
      if (typeof elementProps.className !== 'string'
        || !(elementProps.className.includes('game-server-join-btn')
          || attachToCard && typeof element.type === 'string' && elementProps.className.split(/\s+/).includes('card-item'))) return null;
      // Custom Button components can discard unknown props. Put identity and
      // metrics on the actual native card DOM as well as the legacy Join hook.
      return serverMetricAttributes(props);
    });
  }

  function syncMountedServerMetrics() {
    if (!GAME_PATH.test(routePath())) return;
    const page = document.querySelector?.('#game-detail-page');
    const placeId = Number(routePath().match(/^\/games\/(\d+)(?:\/|$)/)?.[1]);
    if (!page || Number(page.getAttribute('data-place-id')) !== placeId) return;
    for (const card of page.querySelectorAll('#running-game-instances-container .card-item, #rbx-public-running-games .card-item')) {
      try {
        let fiber;
        for (let node = card, depth = 0; node && depth < 3 && !fiber; node = node.parentElement, depth++) {
          const key = Object.keys(node).find(name => /^__react(?:Fiber|InternalInstance)\$/.test(name));
          if (key) fiber = node[key];
        }
        // React can retain the previous host fiber after committing its alternate.
        let root = fiber;
        for (let depth = 0; root?.return && depth < 100; depth++) root = root.return;
        if (root?.stateNode?.current && root.stateNode.current !== root && fiber?.alternate) fiber = fiber.alternate;
        let metrics;
        for (let depth = 0; fiber && depth < 40; depth++, fiber = fiber.return) {
          const props = fiber.memoizedProps;
          if (!metrics && isServerCard(props) && props.serverListType === 'public') metrics = props;
          if (metrics && Array.isArray(props?.gameInstances)) {
            const server = props.gameInstances.find(value => typeof value?.id === 'string' && value.id.toLowerCase() === metrics.id.toLowerCase());
            if (server) metrics = { ...metrics, ...server };
            break;
          }
        }
        if (!metrics) continue;
        const next = serverMetricAttributes(metrics);
        for (const [name, value] of Object.entries(mountedServerAttributes.get(card) || {})) {
          if (!(name in next) && card.getAttribute(name) === String(value)) card.removeAttribute(name);
        }
        for (const [name, value] of Object.entries(next)) {
          if (card.getAttribute(name) !== String(value)) card.setAttribute(name, String(value));
        }
        mountedServerAttributes.set(card, next);
      } catch { /* Unfamiliar React versions leave native cards intact. */ }
    }
  }

  function wrapComponent(type) {
    if (!type || (typeof type !== 'function' && typeof type !== 'object')) return type;
    if (componentTypes.has(type)) return componentTypes.get(type);
    let wrapped = type;
    if (typeof type === 'function' && !type.prototype?.isReactComponent) {
      wrapped = new Proxy(type, {
        apply(target, receiver, args) {
          const previous = renderingFriends;
          renderingFriends = isHomeFriends(args[0]) ? { props: args[0], matched: false } : null;
          try {
            let result = window.RobloxCustomizerFriendsNativeView?.matches(args[0])
              ? window.RobloxCustomizerFriendsNativeView.render(target, receiver, args) : Reflect.apply(target, receiver, args);
            if (isPrivateServerCard(args[0])) {
              try { result = exposePrivateServerIdentity(result, args[0]); }
              catch { /* Keep unfamiliar native cards usable. */ }
            }
            if (isPrivateServerCard(args[0])) {
              try { result = window.RobloxCustomizerServerView?.render(result, args[0]) || result; }
              catch { /* Preserve native cards if a future structure is unfamiliar. */ }
            }
            if (isServerList(args[0]) || isServerCard(args[0])) {
              try {
                return isServerList(args[0])
                  ? exposeServerListMetrics(result, args[0])
                  : exposeServerCardMetrics(result, args[0]);
              } catch { /* Keep Roblox's original server component renderable. */ }
            }
            return result;
          } finally {
            renderingFriends = previous;
          }
        },
      });
    } else if (type.$$typeof === Symbol.for('react.memo')) {
      wrapped = { ...type, type: wrapComponent(type.type) };
    } else if (type.$$typeof === Symbol.for('react.forward_ref')) {
      wrapped = { ...type, render: wrapComponent(type.render) };
    }
    componentTypes.set(type, wrapped);
    componentTypes.set(wrapped, wrapped);
    return wrapped;
  }

  function patchMethod(object, name, handler) {
    if (!object || (typeof object !== 'object' && typeof object !== 'function')) return;
    let methods = patchedMethods.get(object);
    if (!methods) patchedMethods.set(object, methods = new Set());
    if (methods.has(name)) return;

    try {
      const method = object[name];
      if (typeof method !== 'function') return;
      const descriptor = Object.getOwnPropertyDescriptor(object, name);

      if (descriptor && !descriptor.configurable
        && !('value' in descriptor ? descriptor.writable : descriptor.set)) {
        // Webpack's module exports can be non-configurable getter-only properties.
        // They cannot be replaced, so leave the original export untouched.
        methods.add(name);
        return;
      }

      if (descriptor?.get && descriptor.configurable) {
        const proxies = new WeakMap();
        Object.defineProperty(object, name, {
          ...descriptor,
          get() {
            const current = descriptor.get.call(this);
            if (typeof current !== 'function') return current;
            if (!proxies.has(current)) proxies.set(current, new Proxy(current, { apply: handler }));
            return proxies.get(current);
          },
        });
      } else {
        const wrapped = new Proxy(method, { apply: handler });
        if (!descriptor && Object.isExtensible(object)) {
          Object.defineProperty(object, name, {
            configurable: true, enumerable: true, writable: true, value: wrapped,
          });
        } else if (descriptor?.configurable && 'value' in descriptor && !descriptor.writable) {
          Object.defineProperty(object, name, { ...descriptor, value: wrapped });
        } else if (!Reflect.set(object, name, wrapped)) {
          methods.add(name);
          return;
        }
      }
      methods.add(name);
    } catch {
      // A frozen export cannot be patched. Retry only when a new module appears.
      methods.add(name);
    }
  }

  function patchFactory(runtime, name) {
    patchMethod(runtime, name, (target, receiver, args) => {
      if (isHomeFriends(args[1]) || isServerList(args[1]) || isServerCard(args[1]) || isPrivateServerCard(args[1])
        || window.RobloxCustomizerFriendsNativeView?.matches(args[1])) {
        args[0] = wrapComponent(args[0]);
      }
      return Reflect.apply(target, receiver, args);
    });
  }

  function installReact(react) {
    if (!react) return;
    patchFactory(react, 'createElement');
    patchMethod(react, 'useState', (target, receiver, args) => {
      const result = Reflect.apply(target, receiver, args);
      const frame = renderingFriends;
      // The native FriendsList initializes visibleFriendsList with friendsList,
      // then its ResizeObserver truncates that state to one row. Supply the full
      // hydrated list to that one hook while retaining React's original setter.
      if (frame && !frame.matched && Array.isArray(frame.props.friendsList)
        && args[0] === frame.props.friendsList) {
        frame.matched = true;
        return [frame.props.friendsList, result[1]];
      }
      return window.RobloxCustomizerFriendsNativeView?.useState(result, args[0]) || result;
    });
    patchMethod(react, 'useContext', (target, receiver, args) => {
      const result = Reflect.apply(target, receiver, args);
      return window.RobloxCustomizerFriendsNativeView?.useContext(result) || result;
    });
  }

  function installJSX(runtime) {
    for (const name of ['jsx', 'jsxs', 'jsxDEV']) patchFactory(runtime, name);
  }

  function friendRequestUrl(config) {
    if (!/(?:^|\/)home\/?$/i.test(routePath())) return null;
    try {
      const url = new URL(config?.url, location.href);
      return url.origin === 'https://friends.roblox.com' && FIND_PATH.test(url.pathname)
        && !url.searchParams.has('cursor') ? url : null;
    } catch {
      return null;
    }
  }

  async function readRemainingFriends(first, url, get, receiver, args) {
    if (!Array.isArray(first?.data?.PageItems)) return first;
    const deadline = Date.now() + 4000;
    const items = [];
    const ids = new Set();
    const cursors = new Set();
    let data = first.data;
    let cursor = data.NextCursor;
    for (let page = 0; page < MAX_PAGES; page += 1) {
      for (const friend of data.PageItems) {
        if (!Number.isSafeInteger(friend?.id) || ids.has(friend.id)) continue;
        ids.add(friend.id);
        items.push(friend);
        if (items.length >= MAX_FRIENDS) break;
      }
      cursor = data.NextCursor;
      if (items.length >= MAX_FRIENDS || typeof cursor !== 'string' || !cursor
        || cursors.has(cursor) || page === MAX_PAGES - 1) break;
      cursors.add(cursor);
      const nextUrl = new URL(url);
      nextUrl.searchParams.set('limit', '50');
      nextUrl.searchParams.set('cursor', cursor);
      const remaining = deadline - Date.now();
      if (remaining <= 0) break;
      let timeout;
      try {
        // Extra rows must not hold up Roblox's already-loaded first page when
        // a later request stalls. This budget covers all additional pages.
        const next = await Promise.race([
          Reflect.apply(get, receiver, [
            { ...args[0], url: nextUrl.href }, ...args.slice(1),
          ]),
          new Promise((_, reject) => {
            timeout = setTimeout(() => reject(new Error('Friends request timed out')), remaining);
          })
        ]);
        if (!Array.isArray(next?.data?.PageItems)) break;
        data = next.data;
      } catch {
        console.warn('[Roblox Customizer] Could not load the remaining friends; keeping the pages already loaded.');
        break;
      } finally { clearTimeout(timeout); }
    }
    return { ...first, data: { ...first.data, PageItems: items, NextCursor: cursor } };
  }

  function installHttp(http) {
    patchMethod(http, 'get', (target, receiver, args) => {
      const url = friendRequestUrl(args[0]);
      const result = Reflect.apply(target, receiver, args);
      if (!url) return result;
      // Extend the response before Roblox hydrates names, avatars and presence.
      // All rendered friends still go through the official component pipeline.
      return Promise.resolve(result).then(first => readRemainingFriends(first, url, target, receiver, args));
    });
    patchMethod(http, 'post', (target, receiver, args) => {
      const result = Reflect.apply(target, receiver, args);
      return window.RobloxCustomizerFriendsNativeView?.observeWrite(args[0], result) || result;
    });
  }

  function watchProperty(object, name, callback) {
    if (!object || (typeof object !== 'object' && typeof object !== 'function')) return;
    callback(object[name]);
    let names = watchedProperties.get(object);
    if (!names) watchedProperties.set(object, names = new Set());
    if (names.has(name)) return;
    names.add(name);
    const descriptor = Object.getOwnPropertyDescriptor(object, name);
    if (descriptor && (!descriptor.configurable || descriptor.get || descriptor.set || !descriptor.writable)) return;
    let value = object[name];
    Object.defineProperty(object, name, {
      configurable: true,
      enumerable: descriptor?.enumerable ?? true,
      get: () => value,
      set(next) {
        value = next;
        callback(next);
      },
    });
  }

  function connect() {
    watchProperty(window, 'React', installReact);
    watchProperty(window, 'ReactJSX', installJSX);
    watchProperty(window, 'ReactJSXDev', installJSX);
    watchProperty(window, 'Roblox', roblox => {
      watchProperty(roblox, 'core-scripts', core => {
        watchProperty(core, 'http', module => watchProperty(module, 'http', installHttp));
      });
    });
    // Older Roblox deployments expose the same service under CoreUtilities.
    watchProperty(window, 'CoreUtilities', core => watchProperty(core, 'httpService', installHttp));
  }

  // Run launches in Roblox's page context while preserving the user's click gesture.
  document.addEventListener('click', event => {
    if (!event.isTrusted || event.button !== 0 || event.ctrlKey || event.metaKey
      || event.shiftKey || event.altKey || !/^\/home\/?$/i.test(routePath())) return;
    const button = event.target?.closest?.('#rc-pinned-games .rc-pinned-game-join[data-rc-pinned-place-id]');
    if (!button) return;
    const placeId = Number(button.getAttribute('data-rc-pinned-place-id'));
    if (!Number.isSafeInteger(placeId) || placeId <= 0) return;
    const launcher = window.Roblox?.GameLauncher;
    if (typeof launcher?.joinMultiplayerGame !== 'function') return;
    event.preventDefault();
    const failed = () => document.dispatchEvent(new CustomEvent('rc-pinned-game-launch-error'));
    try {
      const result = launcher.joinMultiplayerGame(placeId, true, false);
      if (typeof result?.catch === 'function') result.catch(failed);
    } catch { failed(); }
  }, true);

  document.addEventListener('rc-server-metrics-request', syncMountedServerMetrics);
  connect();
  syncMountedServerMetrics();
  document.addEventListener('load', event => {
    if (event.target?.tagName === 'SCRIPT') { connect(); syncMountedServerMetrics(); }
  }, true);
});
